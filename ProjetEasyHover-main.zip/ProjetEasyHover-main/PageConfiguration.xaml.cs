using ProjetEasyHover.ClassesStatiques;

namespace ProjetEasyHover
{
    public partial class PageConfiguration : ContentPage
    {
        public PageConfiguration()
        {
            InitializeComponent();

            majBoutonsDistanceUnit();
            majBoutonsCoordinatesNotation();
        }

        private async void boutonRetour_clicked(object sender, EventArgs e)
        {
            await Shell.Current.GoToAsync("PageAccueil");
        }

        private void boutonMeters_Clicked(object sender, EventArgs e)
        {
            if (boutonMeters.BackgroundColor != Colors.Salmon)
            {
                ConfigData.paramDistanceUnit_0m_1ft_2km = 0;
                majBoutonsDistanceUnit();
            }
        }

        private void boutonFeets_Clicked(object sender, EventArgs e)
        {
            if (boutonFeets.BackgroundColor != Colors.Salmon)
            {
                ConfigData.paramDistanceUnit_0m_1ft_2km = 1;
                majBoutonsDistanceUnit();
            }
        }

        private void boutonKilometers_Clicked(object sender, EventArgs e)
        {
            if (boutonKilometers.BackgroundColor != Colors.Salmon)
            {
                ConfigData.paramDistanceUnit_0m_1ft_2km = 2;
                majBoutonsDistanceUnit();
            }
        }

        private void majBoutonsDistanceUnit()
        {
            Button[] buttons = new Button[] { boutonMeters, boutonFeets, boutonKilometers };
            Color[][] couleurs = new Color[][] { new Color[] { Colors.Salmon, Colors.Wheat, Colors.Wheat }, new Color[] { Colors.Wheat, Colors.Salmon, Colors.Wheat }, new Color[] { Colors.Wheat, Colors.Wheat, Colors.Salmon } };

            for (int i = 0; i < couleurs.Length; i++)
            {
                buttons[i].BackgroundColor = couleurs[ConfigData.paramDistanceUnit_0m_1ft_2km][i];
            }
        }


        private void majBoutonsCoordinatesNotation()
        {
            Button[] buttons = new Button[] { boutonDD, boutonDDM, boutonDMS };
            Color[][] couleurs = new Color[][] { new Color[] { Colors.Salmon, Colors.Wheat, Colors.Wheat }, new Color[] { Colors.Wheat, Colors.Salmon, Colors.Wheat }, new Color[] { Colors.Wheat, Colors.Wheat, Colors.Salmon } };

            for (int i = 0; i < couleurs.Length; i++)
            {
                buttons[i].BackgroundColor = couleurs[ConfigData.paramCoordinatesNotation_0DD_1DDM_2DMS][i];
            }
        }

        private void boutonDD_Clicked(object sender, EventArgs e)
        {
            if (boutonDD.BackgroundColor != Colors.Salmon)
            {
                ConfigData.paramCoordinatesNotation_0DD_1DDM_2DMS = 0;
                majBoutonsCoordinatesNotation();
            }
        }

        private void boutonDDM_Clicked(object sender, EventArgs e)
        {
            if (boutonDDM.BackgroundColor != Colors.Salmon)
            {
                ConfigData.paramCoordinatesNotation_0DD_1DDM_2DMS = 1;
                majBoutonsCoordinatesNotation();
            }
        }

        private void boutonDMS_Clicked(object sender, EventArgs e)
        {
            if (boutonDMS.BackgroundColor != Colors.Salmon)
            {
                ConfigData.paramCoordinatesNotation_0DD_1DDM_2DMS = 2;
                majBoutonsCoordinatesNotation();
            }
        }
    }
}


namespace ProjetEasyHover;

public partial class PageTutoriel : ContentPage
{
	public PageTutoriel()
	{
		InitializeComponent();
    }
    private async void boutonRetour_clicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("PageAccueil");
    }
}
﻿using ProjetEasyHover.ClassesCanevas;

namespace ProjetEasyHover
{
    public class PageChargement : ContentPage
    {
        public PageChargement()
        {
            Shell.SetNavBarIsVisible(this, false);

            GraphicsView graphiqueChargement = new GraphicsView();
            graphiqueChargement.Drawable = new GraphiquePageDeChargement();

            Grid grilleUnCarreau = new Grid
            {
                RowDefinitions =
            {
                new RowDefinition()
            },
                ColumnDefinitions =
            {
                new ColumnDefinition()
            }
            };

            grilleUnCarreau.Add(graphiqueChargement);

            Content = grilleUnCarreau;

            attendreEtChangerPage();
        }

        private async void attendreEtChangerPage()
        {
            Console.WriteLine("debut attente");
            await Task.Delay(2000);
            Console.WriteLine("fin attente");
            await Shell.Current.GoToAsync("PageAccueil");
        }
    }
}

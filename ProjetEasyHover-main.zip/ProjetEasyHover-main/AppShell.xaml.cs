﻿namespace ProjetEasyHover;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();

        Routing.RegisterRoute("PageAccueil", typeof(PageAccueil));
        Routing.RegisterRoute("PageConfiguration", typeof(PageConfiguration));
        Routing.RegisterRoute("PageTutoriel", typeof(PageTutoriel));
        Routing.RegisterRoute("PageTravailSolOuAir", typeof(PageTravailSolOuAir));
    }
}

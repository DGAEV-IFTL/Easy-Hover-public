﻿using ProjetEasyHover.ClassesStatiques;
using System.Timers;

namespace ProjetEasyHover.ClassesDiverses
{
    public class BoutonAppuiLong : Button
    {
        public bool clicLongConfirmed = false;
        private TimeSpan tempsClicLong = TimeSpan.FromMilliseconds(ConfigData.dureeClicLongEnMillisecondes);
        private System.Timers.Timer _timer;

        //public delegate void Bruh(int lol);
        public event EventHandler ClicCourt;
        public event EventHandler ClicLong;


        public BoutonAppuiLong()
        {
            this.Pressed += BoutonAppuiLong_Pressed;
            this.Released += BoutonAppuiLong_Released;
            this.Clicked += BoutonAppuiLong_Clicked;
        }

        private void BoutonAppuiLong_Pressed(object sender, EventArgs e)
        {
            if (_timer != null)
            {
                _timer.Stop();
            }

            clicLongConfirmed = false;
            _timer = new System.Timers.Timer(tempsClicLong);
            _timer.Elapsed += _timer_Elapsed;
            //Console.WriteLine("timer lancé !! ");
            _timer.Start();
        }

        private void _timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            clicLongConfirmed = true;
            _timer.Stop();
            //Console.WriteLine("clic long confirmé");
            HapticFeedback.Default.Perform(HapticFeedbackType.LongPress);
        }

        private void BoutonAppuiLong_Released(object sender, EventArgs e)
        {
            _timer.Stop();
        }


        private void BoutonAppuiLong_Clicked(object sender, EventArgs e)
        {
            // NOTE : le ? de event?.Invoke() sert à annuler le déclenchement de l'événement quand personne n'y est abonné. Sans ?, une exception est levée lorsque l'event se déclenche alors que personne n'y est abonné.

            if (clicLongConfirmed)
            {                
                ClicLong?.Invoke(sender, e);
            }
            else
            {
                ClicCourt?.Invoke(sender, e);
            }
        }
    }
}

﻿using ProjetEasyHover.ClassesStatiques;


namespace ProjetEasyHover.ClassesDiverses
{
    public class DispositionClavierTactile
    {
        public event EventHandler Abandon;
        public event EventHandler Validation;


        public Grid grilleClaviertactile = new Grid
        {
            Margin = 10,
            RowSpacing = 20,
            ColumnSpacing = 20,
            RowDefinitions =
            {
                new RowDefinition {},
                new RowDefinition {},
                new RowDefinition {},
                new RowDefinition {},
                new RowDefinition {},
                new RowDefinition {},
                new RowDefinition {}
            },
            ColumnDefinitions =
            {
                new ColumnDefinition {},
                new ColumnDefinition {},
                new ColumnDefinition {},
                new ColumnDefinition {},
                new ColumnDefinition {},
                new ColumnDefinition {},
                new ColumnDefinition {},
                new ColumnDefinition {},
                new ColumnDefinition {},
                new ColumnDefinition {},
                new ColumnDefinition {},
                new ColumnDefinition {}
            }
        };



        const string labelEntryHeading = "ENTER HEADING (°)";
        const string labelEntrySetpoint = "ENTER SETPOINT";
        const string labelEntryWindStrength = "ENTER WIND STRENGTH";
        const string labelEntryWindHeading = "ENTER WIND HEADING";

        const string couleurHexaWheat = "F5DEB3";
        const string couleurHexaRed = "FF0000";
        const string couleurHexaGreen = "00FF00";



        int opacityBackgroundAffichageSaisieCapBetween0and255 = 255;
        string colorBackgroundAffichageSaisieCap = couleurHexaWheat;

        public BoutonAppuiLong affichageSaisieCap = new BoutonAppuiLong
        {
            FontSize = 25,
            FontAttributes = FontAttributes.Bold,
            TextColor = Colors.Black,
            BackgroundColor = Color.FromArgb("FF" + couleurHexaWheat), // Colors.Wheat
            // HorizontalTextAlignment = TextAlignment.Center,
            // VerticalTextAlignment = TextAlignment.Center
        };

        string saisieActuelleCap = "";

        const double periodeMillisecondsClignotementlabelSaisie = 1000;
        const int minOpacity = 100;
        const int stepOpacity = 6;
        const double dureeStepChangeOpacity = stepOpacity * periodeMillisecondsClignotementlabelSaisie / (255 - minOpacity);
        bool truePhaseTransparifiante_falsePhaseOpacifiante = true;
        System.Timers.Timer timerClignotementLabelSaisie = new System.Timers.Timer(TimeSpan.FromMilliseconds(dureeStepChangeOpacity));

        /*
        const int ENTREE_CAP = 0;
        const int ENTREE_COORDS = 1;
        const int ENTREE_FORCEVENT = 2;
        const int ENTREE_DIRECTIONVENT = 3;
        */


        public BoutonAppuiLong affichageSaisieLatitude = new BoutonAppuiLong
        {
            FontSize = 20,
            FontAttributes = FontAttributes.Bold,
            TextColor = Colors.Black,
            BackgroundColor = Color.FromArgb("FF" + couleurHexaWheat), // Colors.Wheat
            // HorizontalTextAlignment = TextAlignment.Center,
            // VerticalTextAlignment = TextAlignment.Center
        };

        public BoutonAppuiLong affichageSaisieLongitude = new BoutonAppuiLong
        {
            FontSize = 20,
            FontAttributes = FontAttributes.Bold,
            TextColor = Colors.Black,
            BackgroundColor = Color.FromArgb("FF" + couleurHexaWheat), // Colors.Wheat
            // HorizontalTextAlignment = TextAlignment.Center,
            // VerticalTextAlignment = TextAlignment.Center
        };

        string saisieActuelleLatitude = "";
        string saisieActuelleLongitude = "";




        private int modeClavierTactile_0cap_1coords_2forceVent_3directionVent_RECEPTION;


        public DispositionClavierTactile(int modeClavierTactile_0cap_1coords_2forceVent_3directionVent)
        {
            modeClavierTactile_0cap_1coords_2forceVent_3directionVent_RECEPTION = modeClavierTactile_0cap_1coords_2forceVent_3directionVent;


            if (modeClavierTactile_0cap_1coords_2forceVent_3directionVent == 0)
            {
                affichageSaisieCap.ClicCourt += BoutonClavierTactile_Clicked;
                affichageSaisieCap.ClicLong += LabelSaisieClavierTactile_ClicLong;

                timerClignotementLabelSaisie.Elapsed += TimerClignotementLabelSaisie_Elapsed;
                timerClignotementLabelSaisie.Start();


                Button BoutonBackHaut = creerBoutonClaviertactile("BACK");
                grilleClaviertactile.Add(BoutonBackHaut, 0, 0);
                grilleClaviertactile.SetColumnSpan(BoutonBackHaut, 6);

                Button BoutonEntreeHaut = creerBoutonClaviertactile("OK");
                grilleClaviertactile.Add(BoutonEntreeHaut, 6, 0);
                grilleClaviertactile.SetColumnSpan(BoutonEntreeHaut, 6);

                affichageSaisieCap.Text = labelEntryHeading;
                grilleClaviertactile.Add(affichageSaisieCap, 0, 1);
                grilleClaviertactile.SetColumnSpan(affichageSaisieCap, 9);

                Button BoutonEffacerHaut = creerBoutonClaviertactile("<-");
                grilleClaviertactile.Add(BoutonEffacerHaut, 9, 1);
                grilleClaviertactile.SetColumnSpan(BoutonEffacerHaut, 3);

                for (int i = 1; i <= 12; i++)
                {
                    string caractereAffiched = i.ToString();
                    if (i == 10)
                    {
                        caractereAffiched = "<-";
                    }
                    else if (i == 11)
                    {
                        caractereAffiched = "0";
                    }
                    else if (i == 12)
                    {
                        caractereAffiched = "OK";
                    }

                    Button nouveauBouton = creerBoutonClaviertactile(caractereAffiched);

                    grilleClaviertactile.Add(nouveauBouton, ((i - 1) % 3) * 4, ((i - 1) / 3) + 2);
                    grilleClaviertactile.SetColumnSpan(nouveauBouton, 4);
                }


                Button BoutonBackBas = creerBoutonClaviertactile("BACK");
                grilleClaviertactile.Add(BoutonBackBas, 0, 6);
                grilleClaviertactile.SetColumnSpan(BoutonBackBas, 12);

            }
            else if (modeClavierTactile_0cap_1coords_2forceVent_3directionVent == 1)
            {
                affichageSaisieLatitude.ClicLong += AffichageSaisieLatitude_ClicLong;
                affichageSaisieLongitude.ClicLong += AffichageSaisieLongitude_ClicLong;

                Button BoutonBackHaut = creerBoutonClaviertactile("BACK");
                grilleClaviertactile.Add(BoutonBackHaut, 0, 0);
                grilleClaviertactile.SetColumnSpan(BoutonBackHaut, 6);

                Button BoutonEntreeHaut = creerBoutonClaviertactile("OK");
                grilleClaviertactile.Add(BoutonEntreeHaut, 6, 0);
                grilleClaviertactile.SetColumnSpan(BoutonEntreeHaut, 6);

                affichageSaisieLatitude.Text = "Latitude (DD)";
                grilleClaviertactile.Add(affichageSaisieLatitude, 0, 1);
                grilleClaviertactile.SetColumnSpan(affichageSaisieLatitude, 6);

                affichageSaisieLongitude.Text = "Longitude (DD)";
                grilleClaviertactile.Add(affichageSaisieLongitude, 6, 1);
                grilleClaviertactile.SetColumnSpan(affichageSaisieLongitude, 6);


                for (int i = 1; i <= 12; i++)
                {
                    string caractereAffiched = i.ToString();
                    if (i == 10)
                    {
                        caractereAffiched = ".";
                    }
                    else if (i == 11)
                    {
                        caractereAffiched = "0";
                    }
                    else if (i == 12)
                    {
                        caractereAffiched = "-";
                    }

                    Button nouveauBouton = creerBoutonClaviertactile(caractereAffiched);

                    grilleClaviertactile.Add(nouveauBouton, ((i - 1) % 3) * 4, ((i - 1) / 3) + 2);
                    grilleClaviertactile.SetColumnSpan(nouveauBouton, 4);
                }


                string[] suiteLettres = { "N", "S", "E", "W" };
                for (int i = 0; i < 4; i++)
                {
                    Button nouveauBouton = creerBoutonClaviertactile(suiteLettres[i]);

                    grilleClaviertactile.Add(nouveauBouton, i * 3, 6);
                    grilleClaviertactile.SetColumnSpan(nouveauBouton, 3);
                }

            }
            else if (modeClavierTactile_0cap_1coords_2forceVent_3directionVent == 2)
            {
                affichageSaisieCap.Text = labelEntryWindStrength;

                grilleClaviertactile.Add(affichageSaisieCap, 0, 0);
                grilleClaviertactile.SetColumnSpan(affichageSaisieCap, 11);

                Button BoutonAnnuler = creerBoutonClaviertactile("BACK");
                grilleClaviertactile.Add(BoutonAnnuler, 0, 1);
                grilleClaviertactile.SetColumnSpan(BoutonAnnuler, 7);
            }
            else if (modeClavierTactile_0cap_1coords_2forceVent_3directionVent == 3)
            {
                affichageSaisieCap.Text = labelEntryWindHeading;

                grilleClaviertactile.Add(affichageSaisieCap, 0, 0);
                grilleClaviertactile.SetColumnSpan(affichageSaisieCap, 11);

                Button BoutonAnnuler = creerBoutonClaviertactile("BACK");
                grilleClaviertactile.Add(BoutonAnnuler, 0, 1);
                grilleClaviertactile.SetColumnSpan(BoutonAnnuler, 7);
            }
            else
            {
                // ERROR
                throw new ArgumentException("ERREUR DE MODE : variable modeClavierTactile_0cap_1coords_2forceVent_3directionVent mal initialisée");
            }
        }

        private void AffichageSaisieLongitude_ClicLong(object sender, EventArgs e)
        {
            affichageSaisieLatitude.Text = "44.4606832";
            affichageSaisieLongitude.Text = "-1.2023705";
        }

        private void AffichageSaisieLatitude_ClicLong(object sender, EventArgs e)
        {
            affichageSaisieLatitude.Text = "44.4606832";
            affichageSaisieLongitude.Text = "-1.2023705";
        }

        private void LabelSaisieClavierTactile_ClicLong(object sender, EventArgs e)
        {
            if (fonctionValidationSaisieActuelle())
            {
                faireValidationOuAbandon(true);
            }
        }


        private void TimerClignotementLabelSaisie_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {

            if(truePhaseTransparifiante_falsePhaseOpacifiante)
            {
                opacityBackgroundAffichageSaisieCapBetween0and255 -= stepOpacity;
            }
            else
            {
                opacityBackgroundAffichageSaisieCapBetween0and255 += stepOpacity;
            }

            if(opacityBackgroundAffichageSaisieCapBetween0and255 <= minOpacity)
            {
                opacityBackgroundAffichageSaisieCapBetween0and255 = minOpacity;
                truePhaseTransparifiante_falsePhaseOpacifiante = !truePhaseTransparifiante_falsePhaseOpacifiante;
            }   
            else if (opacityBackgroundAffichageSaisieCapBetween0and255 >= 255)
            {
                opacityBackgroundAffichageSaisieCapBetween0and255 = 255;
                truePhaseTransparifiante_falsePhaseOpacifiante = !truePhaseTransparifiante_falsePhaseOpacifiante;
            }

            string stringOpacity = ConvertUnit.intToHexadecimal(opacityBackgroundAffichageSaisieCapBetween0and255);

            affichageSaisieCap.BackgroundColor = Color.FromArgb(stringOpacity + colorBackgroundAffichageSaisieCap);
        }

        private Button creerBoutonClaviertactile(String valeur)
        {
            var nouveauBouton = new Button
            {
                Text = valeur,
                FontSize = 30,
                FontAttributes = FontAttributes.Bold,
                TextColor = Colors.Black,
                BackgroundColor = Colors.Wheat
                //HorizontalOptions = LayoutOptions.Center,
                //VerticalOptions = LayoutOptions.Center
            };

            nouveauBouton.Clicked += BoutonClavierTactile_Clicked;

            return nouveauBouton;
        }


        private void BoutonClavierTactile_Clicked(object sender, EventArgs e)
        {
            HapticFeedback.Default.Perform(HapticFeedbackType.LongPress);

            Button bouton = (Button)sender;
            Grid grille = (Grid)bouton.Parent;
            //Label label = (Label)grille.Children[0];

            string touchePressed = bouton.Text;

            if(modeClavierTactile_0cap_1coords_2forceVent_3directionVent_RECEPTION == 0)
            {
                if (bouton.GetType() == typeof(BoutonAppuiLong)) // efface tout 
                {
                    saisieActuelleCap = "";
                    fonctionMAJ_labelSaisieClavierTactile(fonctionValidationSaisieActuelle());
                }
                else if (touchePressed == "<-") // efface le dernier caractère
                {
                    if (saisieActuelleCap.Length > 0)
                    {
                        saisieActuelleCap = saisieActuelleCap.Substring(0, saisieActuelleCap.Length - 1);
                        fonctionMAJ_labelSaisieClavierTactile(fonctionValidationSaisieActuelle());
                    }
                }
                else if (touchePressed == "OK")
                {
                    if (fonctionValidationSaisieActuelle())
                    {
                        faireValidationOuAbandon(true);
                    }
                }
                else if (touchePressed == "BACK")
                {
                    faireValidationOuAbandon(false);
                }
                else if (touchePressed == "-")
                {
                    saisieActuelleCap += "-";
                    fonctionMAJ_labelSaisieClavierTactile(fonctionValidationSaisieActuelle());
                }
                else // rajoute le caractère pressé
                {
                    saisieActuelleCap += touchePressed;
                    fonctionMAJ_labelSaisieClavierTactile(fonctionValidationSaisieActuelle());
                }
            }
            else if(modeClavierTactile_0cap_1coords_2forceVent_3directionVent_RECEPTION == 1)
            {
                if (bouton.GetType() == typeof(BoutonAppuiLong)) 
                {
                    saisieActuelleLatitude = "44.4606832";
                    saisieActuelleLongitude = "-1.2023705";

                    affichageSaisieLatitude.Text = "44.4606832";
                    affichageSaisieLongitude.Text = "-1.2023705";
                }
                else if (touchePressed == "<-") // efface le dernier caractère
                {
                    if (saisieActuelleCap.Length > 0)
                    {
                        saisieActuelleCap = saisieActuelleCap.Substring(0, saisieActuelleCap.Length - 1);
                        fonctionMAJ_labelSaisieClavierTactile(fonctionValidationSaisieActuelle());
                    }
                }
                else if (touchePressed == "OK")
                {
                    faireValidationOuAbandon(true);
                    /*
                    if (fonctionValidationSaisieActuelle())
                    {
                        faireValidationOuAbandon(true);
                    }
                    */
                }
                else if (touchePressed == "BACK")
                {
                    faireValidationOuAbandon(false);
                }
                else if (touchePressed == "-")
                {
                    saisieActuelleCap += "-";
                    fonctionMAJ_labelSaisieClavierTactile(fonctionValidationSaisieActuelle());
                }
                else // rajoute le caractère pressé
                {
                    saisieActuelleCap += touchePressed;
                    fonctionMAJ_labelSaisieClavierTactile(fonctionValidationSaisieActuelle());
                }
            }
        }


        private void fonctionMAJ_labelSaisieClavierTactile(bool boolValidation)
        {
            if (saisieActuelleCap.Length == 0)
            {
                affichageSaisieCap.Text = labelEntryHeading;
                colorBackgroundAffichageSaisieCap = couleurHexaWheat;
            }
            else
            {
                if (modeClavierTactile_0cap_1coords_2forceVent_3directionVent_RECEPTION == 0)
                {
                    affichageSaisieCap.Text = saisieActuelleCap + "°";
                }

                if(boolValidation)
                {
                    colorBackgroundAffichageSaisieCap = couleurHexaGreen;
                }
                else
                {
                    colorBackgroundAffichageSaisieCap = couleurHexaRed;
                }
            }
        }

        private bool fonctionValidationSaisieActuelle()
        {
            bool boolValidation = false;

            if (saisieActuelleCap.Length > 0)
            {
                if (modeClavierTactile_0cap_1coords_2forceVent_3directionVent_RECEPTION == 0)
                {
                    if (saisieActuelleCap.Length <= 3 && !saisieActuelleCap.Contains('.'))
                    {
                        int valeurActuelle = int.Parse(saisieActuelleCap);
                        if (valeurActuelle >= 0 && valeurActuelle <= 360)
                        {
                            boolValidation = true;
                        }
                    }
                }
            }

            return boolValidation;
        }

        private void faireValidationOuAbandon(bool trueValidation_falseAbandon)
        {
            if (modeClavierTactile_0cap_1coords_2forceVent_3directionVent_RECEPTION == 0)
            {
                timerClignotementLabelSaisie.Elapsed -= TimerClignotementLabelSaisie_Elapsed;
                timerClignotementLabelSaisie.Stop();

                //DEGUELASSE pour démo
                if (trueValidation_falseAbandon)
                {
                    float valeurFloat = 0;
                    Location valeurLocation = new Location();

                    if (modeClavierTactile_0cap_1coords_2forceVent_3directionVent_RECEPTION == 1)
                    {
                        // [à FAIRE]
                        // récupération des coordonnées à partir de saisie utilisateur
                        valeurLocation = new Location();
                    }
                    else // forcément 0, 2 ou 3 car sinon exception lancée dans le constructeur
                    {
                        valeurFloat = float.Parse(saisieActuelleCap);
                    }

                    ValidationEventArgs validationEventArgs = new ValidationEventArgs(modeClavierTactile_0cap_1coords_2forceVent_3directionVent_RECEPTION, valeurFloat, valeurLocation);

                    Validation?.Invoke(this, validationEventArgs);
                }
                else
                {
                    Abandon?.Invoke(this, new EventArgs());
                }
            }
            else if (modeClavierTactile_0cap_1coords_2forceVent_3directionVent_RECEPTION == 1)
            {
                //DEGUELASSE pour démo
                if (trueValidation_falseAbandon)
                {
                    float valeurFloat = 0;
                    Location valeurLocation = new Location();

                    if (modeClavierTactile_0cap_1coords_2forceVent_3directionVent_RECEPTION == 1)
                    {
                        // [à FAIRE]
                        // récupération des coordonnées à partir de saisie utilisateur
                        valeurLocation = new Location(44.4606832, -1.2023705);
                    }
                    else // forcément 0, 2 ou 3 car sinon exception lancée dans le constructeur
                    {
                        valeurFloat = float.Parse(saisieActuelleCap);
                    }

                    ValidationEventArgs validationEventArgs = new ValidationEventArgs(modeClavierTactile_0cap_1coords_2forceVent_3directionVent_RECEPTION, valeurFloat, valeurLocation);

                    Validation?.Invoke(this, validationEventArgs);
                }
                else
                {
                    Abandon?.Invoke(this, new EventArgs());
                }
            }

                /*
                if(trueValidation_falseAbandon)
                {
                    float valeurFloat = 0;
                    Location valeurLocation = new Location();

                    if (modeClavierTactile_0cap_1coords_2forceVent_3directionVent_RECEPTION == 1)
                    {
                        // [à FAIRE]
                        // récupération des coordonnées à partir de saisie utilisateur
                        valeurLocation = new Location();
                    }
                    else // forcément 0, 2 ou 3 car sinon exception lancée dans le constructeur
                    {
                        valeurFloat = float.Parse(saisieActuelleCap);
                    }

                    ValidationEventArgs validationEventArgs = new ValidationEventArgs(modeClavierTactile_0cap_1coords_2forceVent_3directionVent_RECEPTION, valeurFloat, valeurLocation);

                    Validation?.Invoke(this, validationEventArgs);
                }
                else
                {
                    Abandon?.Invoke(this, new EventArgs());
                }
                */
            }
    }
}

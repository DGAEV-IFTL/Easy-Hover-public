﻿

namespace ProjetEasyHover.ClassesDiverses
{
    public class ValidationEventArgs : EventArgs
    {
        public int modeClavierTactile_0cap_1coords_2forceVent_3directionVent { get; private set; } = 0;
        public float capSaisieUtilisateur { get; private set; } = 0;
        public Location coordsSaisieUtilisateur { get; private set;} = new Location();
        public float forceVentSaisieUtilisateur { get; private set; } = 0;
        public float directionVentSaisieUtilisateur { get; private set; } = 0;

        public ValidationEventArgs(int modeClavierTactile_0cap_1coords_2forceVent_3directionVent_constructeur, float valeurFloat, Location valeurLocation)
        {
            modeClavierTactile_0cap_1coords_2forceVent_3directionVent = modeClavierTactile_0cap_1coords_2forceVent_3directionVent_constructeur;

            if(modeClavierTactile_0cap_1coords_2forceVent_3directionVent == 0)
            {
                capSaisieUtilisateur = valeurFloat;
            }
            else if (modeClavierTactile_0cap_1coords_2forceVent_3directionVent == 1)
            {
                coordsSaisieUtilisateur = valeurLocation;
            }
            else if (modeClavierTactile_0cap_1coords_2forceVent_3directionVent == 2)
            {
                forceVentSaisieUtilisateur = valeurFloat;
            }
            else if (modeClavierTactile_0cap_1coords_2forceVent_3directionVent == 3)
            {
                directionVentSaisieUtilisateur = valeurFloat;
            }
            else
            {
                throw new ArgumentException("ERREUR DE MODE : variable modeClavierTactile_0cap_1coords_2forceVent_3directionVent mal initialisée");
            }
        }
    }
}

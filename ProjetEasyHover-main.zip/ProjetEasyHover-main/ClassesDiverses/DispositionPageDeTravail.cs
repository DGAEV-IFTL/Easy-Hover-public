﻿using ProjetEasyHover.ClassesCanevas;
using ProjetEasyHover.ClassesStatiques;

namespace ProjetEasyHover.ClassesDiverses
{
    public class DispositionPageDeTravail
    {
        public GraphicsView monCanevas = new GraphicsView();
        public GraphiquePageDeTravail objetGraphiqueEasyHover;




        public Grid grillePageDeTravail = new Grid
        {
            BackgroundColor = Colors.DarkBlue,
            RowDefinitions =
            {
                new RowDefinition{Height = new GridLength(1, GridUnitType.Star)},
                new RowDefinition{Height = new GridLength(2, GridUnitType.Star)}
            }
        };

        public BoxView boxBas = new BoxView
        {
            Color = Colors.DarkBlue
        };

        public Grid grilleHaut = new Grid
        {
            Margin = 5,
            ColumnSpacing = 10,
            RowSpacing = 10,
            RowDefinitions =
            {
                new RowDefinition{Height = new GridLength(1, GridUnitType.Star)},
                new RowDefinition{Height = new GridLength(1, GridUnitType.Star)},
                new RowDefinition{Height = new GridLength(1, GridUnitType.Star)},
                new RowDefinition{Height = new GridLength(1, GridUnitType.Star)},
                new RowDefinition{Height = new GridLength(1, GridUnitType.Star)},
                new RowDefinition{Height = new GridLength(1, GridUnitType.Star)}
            },

            ColumnDefinitions =
            {
                new ColumnDefinition{Width = new GridLength(1, GridUnitType.Star)},
                new ColumnDefinition{Width = new GridLength(1, GridUnitType.Star)},
                new ColumnDefinition{Width = new GridLength(1, GridUnitType.Star)},
                new ColumnDefinition{Width = new GridLength(1, GridUnitType.Star)},
                new ColumnDefinition{Width = new GridLength(1, GridUnitType.Star)}
            }
        };






        public BoutonAppuiLong boutonRetour = new BoutonAppuiLong
        {
            TextColor = Colors.Black,
            Text = "BACK",
            BackgroundColor = Colors.Wheat,
            FontSize = 24,
            FontAttributes = FontAttributes.Bold
            //Margin = 15
            //HorizontalOptions = LayoutOptions.Center,
            //VerticalOptions = LayoutOptions.Center
        };


        public BoutonAppuiLong boutonChrono = new BoutonAppuiLong
        {
            TextColor = Colors.Black,
            Text = "CHRONO",
            BackgroundColor = Colors.Wheat,
            FontSize = 24,
            FontAttributes = FontAttributes.Bold
        };





        public BoutonAppuiLong boutonCoords = new BoutonAppuiLong
        {
            BackgroundColor = Colors.Wheat,
            //HorizontalOptions = LayoutOptions.Center,
            //VerticalOptions = LayoutOptions.Center
        };


        public Label lblCoords = new Label
        {
            TextColor = Colors.Black,
            Text = "SETPOINT : ",
            FontSize = 24,
            FontAttributes = FontAttributes.Bold,

            HorizontalOptions = LayoutOptions.Center,
            VerticalOptions = LayoutOptions.Center
        };

        public Label lblLatitude = new Label
        {
            TextColor = Colors.Black,
            Text = "Lat : None",
            FontSize = 13,
            FontAttributes = FontAttributes.Bold,
            HorizontalOptions = LayoutOptions.Start,
            VerticalOptions = LayoutOptions.Center
        };

        public Label lblLongitude = new Label
        {
            TextColor = Colors.Black,
            Text = "Lon : None",
            FontSize = 13,
            FontAttributes = FontAttributes.Bold,
            HorizontalOptions = LayoutOptions.Start,
            VerticalOptions = LayoutOptions.Center
        };

        public ActivityIndicator chargementPlot = new ActivityIndicator
        {
            Color = Colors.Red,
            IsRunning = false
        };




        public Button fondEnsembleCaptracking = new Button
        {
            BackgroundColor = Colors.Wheat
        };

        public Label lblCap = new Label
        {
            Text = "HEADING :",
            TextColor = Colors.Black,
            FontSize = 24,
            HorizontalOptions = LayoutOptions.Center,
            VerticalOptions = LayoutOptions.Center,
            FontAttributes = FontAttributes.Bold
        };

        public Switch switchModeCapTrueAuto_falseManuel = new Switch
        {
            IsToggled = false,
            OnColor = Colors.Black,
            ThumbColor = Colors.White,
            HorizontalOptions = LayoutOptions.Center,
            VerticalOptions = LayoutOptions.Start
        };

        public Label lblCapManuelOuAuto = new Label
        {
            Text = "Manual",
            TextColor = Colors.Black,
            FontSize = 16,
            FontAttributes = FontAttributes.Bold,
            HorizontalOptions = LayoutOptions.Center,
            VerticalOptions = LayoutOptions.Center
        };








        /*
        public Label lblTracking = new Label
        {
            Text = "TRACKING :",
            TextColor = Colors.Black,
            FontSize = 18,
            HorizontalOptions = LayoutOptions.Center,
            VerticalOptions = LayoutOptions.Center,
            FontAttributes = FontAttributes.Bold
        };

        public Label lblNbrDeGeolocs = new Label
        {
            Text = "0",
            TextColor = Colors.Black,
            FontSize = 14,
            HorizontalOptions = LayoutOptions.Center,
            VerticalOptions = LayoutOptions.Center,
            FontAttributes = FontAttributes.Bold
        };
        */


        public Button fondEnsembleGeoTracking = new Button
        {
            BackgroundColor = Colors.Wheat
        };

        public Label lblTrackingOnOff = new Label
        {
            Text = "START\n",
            TextColor = Colors.Black,
            FontAttributes = FontAttributes.Bold,
            FontSize = 24,
            HorizontalOptions = LayoutOptions.Center,
            VerticalOptions = LayoutOptions.Center
        };

        public Switch switchGeoTrackingOnOff = new Switch
        {
            IsToggled = false,
            OnColor = Colors.Black,
            ThumbColor = Colors.White,
            HorizontalOptions = LayoutOptions.Center,
            VerticalOptions = LayoutOptions.Start
        };


        public BoxView frameIndicatricePrecisionEtTemoinAcquisitionGeoloc = new BoxView
        {
            Color = Colors.Black,
            CornerRadius = 5
        };

        public BoxView frameIndicatricePrecisionEtTemoinAcquisitionGeoloc2 = new BoxView
        {
            Color = Colors.Wheat,
            CornerRadius = 5,
            Margin = 10

        };



        public DispositionPageDeTravail()
        {
            monCanevas.Drawable = new GraphiquePageDeTravail();
            objetGraphiqueEasyHover = (GraphiquePageDeTravail)monCanevas.Drawable;

            if(!ConfigData.trueStationnaireSol_falseStationnaireAir)
            {
                grillePageDeTravail.Add(new BoxView { Color = Colors.Red}, 0, 0);
            }
            grillePageDeTravail.Add(boxBas, 0, 1);
            grillePageDeTravail.Add(monCanevas, 0, 1);

            

            grilleHaut.Add(boutonRetour, 0, 0);
            grilleHaut.SetColumnSpan(boutonRetour, 2);
            grilleHaut.SetRowSpan(boutonRetour, 2);

            

            grilleHaut.Add(fondEnsembleCaptracking, 2, 0);
            grilleHaut.SetColumnSpan(fondEnsembleCaptracking, 3);
            grilleHaut.SetRowSpan(fondEnsembleCaptracking, 2);

            grilleHaut.Add(lblCap, 2, 0);
            grilleHaut.SetColumnSpan(lblCap, 2);
            grilleHaut.SetRowSpan(lblCap, 2);

            grilleHaut.Add(switchModeCapTrueAuto_falseManuel, 4, 0);
            grilleHaut.SetColumnSpan(switchModeCapTrueAuto_falseManuel, 1);
            grilleHaut.SetRowSpan(switchModeCapTrueAuto_falseManuel, 1);

            grilleHaut.Add(lblCapManuelOuAuto, 4, 1);
            grilleHaut.SetColumnSpan(lblCapManuelOuAuto, 1);
            grilleHaut.SetRowSpan(lblCapManuelOuAuto, 1);





            grilleHaut.Add(boutonCoords, 0, 2);
            grilleHaut.SetColumnSpan(boutonCoords, 5);
            grilleHaut.SetRowSpan(boutonCoords, 2);

            grilleHaut.Add(lblCoords, 0, 2);
            grilleHaut.SetColumnSpan(lblCoords, 2);
            grilleHaut.SetRowSpan(lblCoords, 2);

            grilleHaut.Add(lblLatitude, 2, 2);
            grilleHaut.SetColumnSpan(lblLatitude, 2);
            grilleHaut.SetRowSpan(lblLatitude, 1);

            grilleHaut.Add(lblLongitude, 2, 3);
            grilleHaut.SetColumnSpan(lblLongitude, 2);
            grilleHaut.SetRowSpan(lblLongitude, 1);

            grilleHaut.Add(chargementPlot, 4, 2);
            grilleHaut.SetColumnSpan(chargementPlot, 1);
            grilleHaut.SetRowSpan(chargementPlot, 2);





            grilleHaut.Add(boutonChrono, 0, 4);
            grilleHaut.SetColumnSpan(boutonChrono, 2);
            grilleHaut.SetRowSpan(boutonChrono, 2);







            grilleHaut.Add(fondEnsembleGeoTracking, 2, 4);
            grilleHaut.SetColumnSpan(fondEnsembleGeoTracking, 2);
            grilleHaut.SetRowSpan(fondEnsembleGeoTracking, 2);

            /*
            grilleHaut.Add(lblNbrDeGeolocs, 3, 5);
            grilleHaut.SetColumnSpan(lblTracking, 3);
            grilleHaut.SetRowSpan(lblTracking, 1);

            grilleHaut.Add(lblTracking, 3, 4);
            grilleHaut.SetColumnSpan(lblTracking, 2);
            grilleHaut.SetRowSpan(lblTracking, 2);
            */

            grilleHaut.Add(lblTrackingOnOff, 2, 4);
            grilleHaut.SetColumnSpan(lblTrackingOnOff, 2);
            grilleHaut.SetRowSpan(lblTrackingOnOff, 2);

            grilleHaut.Add(switchGeoTrackingOnOff, 2, 5);
            grilleHaut.SetColumnSpan(switchGeoTrackingOnOff, 2);
            grilleHaut.SetRowSpan(switchGeoTrackingOnOff, 1);





            grilleHaut.Add(frameIndicatricePrecisionEtTemoinAcquisitionGeoloc, 4, 4);
            grilleHaut.SetColumnSpan(frameIndicatricePrecisionEtTemoinAcquisitionGeoloc, 1);
            grilleHaut.SetRowSpan(frameIndicatricePrecisionEtTemoinAcquisitionGeoloc, 2);

            grilleHaut.Add(frameIndicatricePrecisionEtTemoinAcquisitionGeoloc2, 4, 4);
            grilleHaut.SetColumnSpan(frameIndicatricePrecisionEtTemoinAcquisitionGeoloc2, 1);
            grilleHaut.SetRowSpan(frameIndicatricePrecisionEtTemoinAcquisitionGeoloc2, 2);




            grillePageDeTravail.Add(grilleHaut);
        }

    }
}

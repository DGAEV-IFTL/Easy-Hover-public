using ProjetEasyHover.ClassesStatiques;
using System.Timers;

namespace ProjetEasyHover;

public partial class PageTravailSolOuAir : ContentPage
{
    int count = 0;

    PointF startPoint;
    PointF startPointDragSpecial;

    float startCap = 0;

    bool clicSimple;
    float startDistanceEntreDeuxDoigts = 0;
    float startPourcentageEchelle = 0;
    float deltaPinchDistanceDemiEcran = 0;

    float deltaCapSouhaited;

    System.Timers.Timer timerClicCourt;
    System.Timers.Timer timerClicLong;
    System.Timers.Timer timerAnimationTeleportationBoussole;
    System.Timers.Timer timerAnimationClicLong;


    private void initTimersEtInteractionsCanevas()
    {

        disp.monCanevas.StartInteraction += ClockGraphicsView_StartInteraction;
        disp.monCanevas.DragInteraction += ClockGraphicsView_DragInteraction;
        disp.monCanevas.EndInteraction += ClockGraphicsView_EndInteraction;



        timerClicCourt = new System.Timers.Timer(disp.objetGraphiqueEasyHover.TEMPS_CLIC_COURT);
        timerClicCourt.Elapsed += new ElapsedEventHandler(timerClicCourt_elapsed);

        timerClicLong = new System.Timers.Timer(disp.objetGraphiqueEasyHover.TEMPS_CLIC_LONG);
        timerClicLong.Elapsed += new ElapsedEventHandler(timerClicLong_elapsed);

        timerAnimationClicLong = new System.Timers.Timer(disp.objetGraphiqueEasyHover.TEMPS_ANIMATION_CLIC_LONG);
        timerAnimationClicLong.Elapsed += new ElapsedEventHandler(timerAnimationClicLong_elapsed);

        timerAnimationTeleportationBoussole = new System.Timers.Timer(disp.objetGraphiqueEasyHover.TEMPS_ANIMATION_TELEPORTATION_BOUSSOLE / disp.objetGraphiqueEasyHover.NBR_ANIMATIONS_TELEPORTATION_BOUSSOLE);
        timerAnimationTeleportationBoussole.Elapsed += new ElapsedEventHandler(timerAnimationTeleportationBoussole_elapsed);
    }




    public void timerClicCourt_elapsed(object source, ElapsedEventArgs e)
    {
        if (clicSimple)
        {
            timerClicCourt.Stop();

            disp.objetGraphiqueEasyHover.affichageTraceClic = true;
            disp.objetGraphiqueEasyHover.pointClic = startPoint;
            timerClicLong.Start();
            timerAnimationClicLong.Start();

            disp.monCanevas.Invalidate();
        }
    }



    public void timerClicLong_elapsed(object source, ElapsedEventArgs e)
    {
        if (clicSimple)
        {
            timerAnimationClicLong.Stop();
            timerClicLong.Stop();

            disp.objetGraphiqueEasyHover.progressionClicLong = 1;
            disp.objetGraphiqueEasyHover.clicLongVerrouilled = true;
            //objetCanevas.endAngleArcClic = 360;
            //objetCanevas.currentEpaisseurArcClic = objetCanevas.minEpaisseurArcClic;
            HapticFeedback.Default.Perform(HapticFeedbackType.LongPress);
            Console.WriteLine("VERROUILLED !");

            disp.monCanevas.Invalidate();
        }
    }



    public void timerAnimationTeleportationBoussole_elapsed(object source, ElapsedEventArgs e)
    {
        if (clicSimple)
        {
            disp.objetGraphiqueEasyHover.currentAnimationTeleportationBoussole++;


            float xEntre0et1 = (float)disp.objetGraphiqueEasyHover.currentAnimationTeleportationBoussole / (float)disp.objetGraphiqueEasyHover.NBR_ANIMATIONS_TELEPORTATION_BOUSSOLE;
            float paraboleInversed = -(xEntre0et1 * xEntre0et1) + 2 * xEntre0et1;
            disp.objetGraphiqueEasyHover.capActuelBoussole = startCap + deltaCapSouhaited * paraboleInversed;

            if (disp.objetGraphiqueEasyHover.currentAnimationTeleportationBoussole >= disp.objetGraphiqueEasyHover.NBR_ANIMATIONS_TELEPORTATION_BOUSSOLE)
            {
                disp.objetGraphiqueEasyHover.capActuelBoussole = startCap + deltaCapSouhaited;
                startCap = 0; //
                timerAnimationTeleportationBoussole.Stop();
                disp.objetGraphiqueEasyHover.currentAnimationTeleportationBoussole = 0;
            }

            disp.monCanevas.Invalidate();
        }
    }
    public void timerAnimationClicLong_elapsed(object source, ElapsedEventArgs e)
    {
        if (clicSimple)
        {
            disp.objetGraphiqueEasyHover.progressionClicLong += (float)disp.objetGraphiqueEasyHover.TEMPS_ANIMATION_CLIC_LONG / (float)disp.objetGraphiqueEasyHover.TEMPS_CLIC_LONG;
            disp.monCanevas.Invalidate();
        }
    }






    private void ClockGraphicsView_StartInteraction(object sender, TouchEventArgs e)
    {
        if (e.Touches.Length >= 2)
        {
            startDistanceEntreDeuxDoigts = FonctionsUtils.calculDistancePoints(e.Touches[0], e.Touches[1]);
            startPourcentageEchelle = disp.objetGraphiqueEasyHover.pourcentageEchelle;

            clicSimple = false;

            timerClicCourt.Stop();
            timerClicLong.Stop();
            timerAnimationTeleportationBoussole.Stop();
            timerAnimationClicLong.Stop();

            disp.objetGraphiqueEasyHover.affichageTraceClic = false;
            disp.objetGraphiqueEasyHover.progressionClicLong = 0;
            disp.objetGraphiqueEasyHover.clicLongVerrouilled = false;
            disp.objetGraphiqueEasyHover.dragSpecial = false;
            count = 0;

            disp.monCanevas.Invalidate();
        }
        else
        {
            clicSimple = true;
            startPoint = e.Touches[0];
            startCap = disp.objetGraphiqueEasyHover.capActuelBoussole;

            timerClicCourt.Start();

            Console.WriteLine("OOOOH OUI ");
            Console.WriteLine("startPoint : " + startPoint);
        }
    }


    private void ClockGraphicsView_DragInteraction(object sender, TouchEventArgs e)
    {
        if (clicSimple)
        {
            if (!disp.objetGraphiqueEasyHover.clicLongVerrouilled)
            {
                disp.objetGraphiqueEasyHover.affichageTraceClic = false;
                timerClicLong.Stop();
                timerAnimationClicLong.Stop();
                timerClicCourt.Stop();

                float angleDegreesTouched = FonctionsUtils.calculDegreePointB_relatifTo_pointA(disp.objetGraphiqueEasyHover.POINT_CENTRE, e.Touches[0]);

                capRegledManuellement();
                disp.objetGraphiqueEasyHover.capActuelBoussole = startCap - angleDegreesTouched + FonctionsUtils.calculDegreePointB_relatifTo_pointA(disp.objetGraphiqueEasyHover.POINT_CENTRE, startPoint);

                disp.monCanevas.Invalidate();
            }
            else
            {
                if (!disp.objetGraphiqueEasyHover.dragSpecial)
                {
                    if (FonctionsUtils.calculDistancePoints(e.Touches[0], startPoint) > disp.objetGraphiqueEasyHover.WIDTH_ARC_CLIC / 2)
                    {
                        disp.objetGraphiqueEasyHover.dragSpecial = true;
                        startPointDragSpecial = e.Touches[0];
                    }
                }
                else
                {
                    disp.objetGraphiqueEasyHover.toucheActuel = e.Touches[0];
                    float angleDegreesTouched = FonctionsUtils.calculDegreePointB_relatifTo_pointA(startPoint, e.Touches[0]);

                    capRegledManuellement();
                    disp.objetGraphiqueEasyHover.capActuelBoussole = startCap - angleDegreesTouched + FonctionsUtils.calculDegreePointB_relatifTo_pointA(startPoint, startPointDragSpecial);

                    disp.monCanevas.Invalidate();
                }
            }

            count++;
        }
        else if (e.Touches.Length >= 2)
        {
            float distanceEntreDeuxDoigtsActuelle = FonctionsUtils.calculDistancePoints(e.Touches[0], e.Touches[1]);
            float rapportPinchActuel = distanceEntreDeuxDoigtsActuelle / startDistanceEntreDeuxDoigts;
            disp.objetGraphiqueEasyHover.pourcentageEchelle = startPourcentageEchelle / rapportPinchActuel;
            if (disp.objetGraphiqueEasyHover.pourcentageEchelle > 1)
            {
                disp.objetGraphiqueEasyHover.pourcentageEchelle = 1;
            }
            else if (disp.objetGraphiqueEasyHover.pourcentageEchelle < 0.01)
            {
                disp.objetGraphiqueEasyHover.pourcentageEchelle = (float)0.01;
            }
            disp.monCanevas.Invalidate();
        }
    }


    private void ClockGraphicsView_EndInteraction(object sender, TouchEventArgs e)
    {
        if (clicSimple)
        {
            bool clicCourt = !disp.objetGraphiqueEasyHover.clicLongVerrouilled && count <= 3; //  si c'est un clic court sur le canevas
            bool clicLong = disp.objetGraphiqueEasyHover.clicLongVerrouilled && !disp.objetGraphiqueEasyHover.dragSpecial; // si c'est un clic long

            bool clicRien = true;
            bool clicBoussole = false;
            bool clicCentre = false;
            bool clicCap = false;
            bool clicBulle = false;
            int numBulleClicked = -30;


            if (clicCourt)
            {
                float capAvantClic = disp.objetGraphiqueEasyHover.capActuelBoussole;
                while (!clicBulle && numBulleClicked < 330)
                {
                    numBulleClicked += 30;

                    float vraieProportionGraduationBulle = disp.objetGraphiqueEasyHover.vraieProportionGraduationBoussole(numBulleClicked, capAvantClic);
                    float vraiTailleGraduationBulle = disp.objetGraphiqueEasyHover.TAILLE_GRADUATIONS * disp.objetGraphiqueEasyHover.PROPORTION10;
                    float vraiEpaisseurGraduationBulle = disp.objetGraphiqueEasyHover.EPAISSEUR_GRADUATIONS * vraieProportionGraduationBulle;

                    float distanceCentreBoussoleEtCentreBulle = disp.objetGraphiqueEasyHover.RAYON_CERCLE_GRADUATIONS_BOUSSOLE + disp.objetGraphiqueEasyHover.TAILLE_ECART_CERCLE + vraiTailleGraduationBulle + disp.objetGraphiqueEasyHover.RAYON_TEXTE_GRADUATION;
                    PointF centreCercletexteGraduation = FonctionsUtils.calculPointF_pointCentreRayonAngleDegree(disp.objetGraphiqueEasyHover.POINT_CENTRE, distanceCentreBoussoleEtCentreBulle, numBulleClicked - capAvantClic);
                    float hypoth�nuseBulle = FonctionsUtils.calculDistancePoints(centreCercletexteGraduation, startPoint);

                    if (hypoth�nuseBulle <= disp.objetGraphiqueEasyHover.RAYON_TEXTE_GRADUATION + vraiEpaisseurGraduationBulle)
                    {
                        clicBulle = true;
                        clicRien = false;
                        teleporterBoussoleAvecAnimation(numBulleClicked);
                    }
                }
            }

            if (!clicBulle)
            {
                float hypoth�nuseClicCentre = FonctionsUtils.calculDistancePoints(disp.objetGraphiqueEasyHover.POINT_CENTRE, startPoint);

                clicBoussole = hypoth�nuseClicCentre >= disp.objetGraphiqueEasyHover.RAYON_CERCLE_GRADUATIONS_BOUSSOLE - 40 && hypoth�nuseClicCentre <= disp.objetGraphiqueEasyHover.RAYON_CERCLE_GRADUATIONS_BOUSSOLE + disp.objetGraphiqueEasyHover.TAILLE_ECART_CERCLE + disp.objetGraphiqueEasyHover.TAILLE_GRADUATIONS * disp.objetGraphiqueEasyHover.PROPORTION10 * disp.objetGraphiqueEasyHover.PROPORTION_CURRENT + 2 * disp.objetGraphiqueEasyHover.RAYON_TEXTE_GRADUATION + disp.objetGraphiqueEasyHover.EPAISSEUR_GRADUATIONS * disp.objetGraphiqueEasyHover.PROPORTION10 * disp.objetGraphiqueEasyHover.PROPORTION_CURRENT / 2;
                clicCentre = hypoth�nuseClicCentre <= 60;
                clicCap = startPoint.X >= disp.objetGraphiqueEasyHover.CADRE_CAP.X && startPoint.X <= disp.objetGraphiqueEasyHover.CADRE_CAP.X + disp.objetGraphiqueEasyHover.CADRE_CAP.Width && startPoint.Y >= disp.objetGraphiqueEasyHover.CADRE_CAP.Y && startPoint.Y <= disp.objetGraphiqueEasyHover.CADRE_CAP.Y + disp.objetGraphiqueEasyHover.CADRE_CAP.Height;

                clicRien = !((clicBoussole && !clicCentre && !clicCap) || (!clicBoussole && clicCentre && !clicCap) || (!clicBoussole && !clicCentre && clicCap)); // au cas o� il y ait ambiguit� entre les diff�rentes zones de clic

                if (clicCourt)
                {
                    if (clicRien)
                    {
                        //disp.boxBas.Color = disp.boxBas.Color != Colors.Red ? Colors.Red : Colors.Blue;
                    }
                    else if (clicBoussole)
                    {
                        teleporterBoussoleAvecAnimation(FonctionsUtils.calculDegreePointB_relatifTo_pointA(disp.objetGraphiqueEasyHover.POINT_CENTRE, startPoint) + disp.objetGraphiqueEasyHover.capActuelBoussole);
                    }
                    else if (clicCentre)
                    {
                        //disp.boxBas.Color = disp.boxBas.Color != Colors.Black ? Colors.Black : Colors.Blue;
                        disp.objetGraphiqueEasyHover.setPointLocationObjectif(null);
                        disp.switchGeoTrackingOnOff.IsToggled = false;
                        disp.switchGeoTrackingOnOff.IsToggled = true;
                    }
                    else if (clicCap)
                    {
                        //disp.boxBas.Color = disp.boxBas.Color != Colors.Pink ? Colors.Pink : Colors.Blue;
                        BoutonCap_Clicked();
                    }
                }
                else if (clicLong)
                {
                    if (clicRien)
                    {
                        //disp.boxBas.Color = disp.boxBas.Color != Colors.Gray ? Colors.Gray : Colors.Blue;
                    }
                    else if (clicBoussole)
                    {
                        teleporterBoussoleAvecAnimation(0);
                    }
                    else if (clicCentre)
                    {
                        //disp.boxBas.Color = disp.boxBas.Color != Colors.White ? Colors.White : Colors.Blue;
                        arreterTrackingArreterAffichage();
                    }
                    else if (clicCap)
                    {
                        //disp.boxBas.Color = disp.boxBas.Color != Colors.DeepPink ? Colors.DeepPink : Colors.Blue;
                        teleporterBoussoleAvecAnimation(0);
                    }
                }
            }
        }




        disp.monCanevas.Invalidate();

        disp.objetGraphiqueEasyHover.affichageTraceClic = false;
        disp.objetGraphiqueEasyHover.progressionClicLong = 0;
        disp.objetGraphiqueEasyHover.clicLongVerrouilled = false;
        disp.objetGraphiqueEasyHover.dragSpecial = false;
        timerClicCourt.Stop();
        timerClicLong.Stop();
        timerAnimationClicLong.Stop();
        count = 0;
        disp.objetGraphiqueEasyHover.capActuelBoussole = FonctionsUtils.remettreAngleEntre0et360(disp.objetGraphiqueEasyHover.capActuelBoussole);

    }

    private void teleporterBoussoleAvecAnimation(float degreeObjectif)
    {
        capRegledManuellement();
        startCap = disp.objetGraphiqueEasyHover.capActuelBoussole;
        deltaCapSouhaited = FonctionsUtils.cheminLePlusCourtPourAllerDeAngleA_toAngleB(disp.objetGraphiqueEasyHover.capActuelBoussole, degreeObjectif);
        timerAnimationTeleportationBoussole.Start();
    }
}
﻿using ProjetEasyHover.ClassesStatiques;

namespace ProjetEasyHover;

public partial class PageAccueil : ContentPage
{
    public PageAccueil()
    {
        InitializeComponent();
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();

        boutonStationnaireSol.IsEnabled = true;
        boutonStationnaireAir.IsEnabled = true;
        boutonConfiguration.IsEnabled = true;
        boutonTutoriel.IsEnabled = true;
    }

    protected override bool OnBackButtonPressed()
    {
        Console.WriteLine("retour !");

        //return base.OnBackButtonPressed();
        return true; // pour empêcher le fonctionnement du bouton retour sur la page d'accueil
    }

    private async void stationnaireSol_clicked(object sender, EventArgs e)
    {
        ConfigData.trueStationnaireSol_falseStationnaireAir = true;
        boutonStationnaireSol.IsEnabled = false;

        await Shell.Current.GoToAsync("PageTravailSolOuAir");


        //var newPage = new PageTravailSolOuAir();
        //await Navigation.PushAsync(newPage);

        //await Shell.Current.GoToAsync("PageTravailSolOuAir?");     Navigation.pu   
    }

    private async void stationnaireAir_clicked(object sender, EventArgs e)
    {
        ConfigData.trueStationnaireSol_falseStationnaireAir = false;
        boutonStationnaireAir.IsEnabled = false;

        await Shell.Current.GoToAsync("PageTravailSolOuAir");
    }

    private async void configuration_clicked(object sender, EventArgs e)
    {
        boutonConfiguration.IsEnabled = false;

        await Shell.Current.GoToAsync("PageConfiguration");
    }

    private async void tutoriel_clicked(object sender, EventArgs e)
    {
        boutonTutoriel.IsEnabled = false;

        await Shell.Current.GoToAsync("PageTutoriel");
    }
}


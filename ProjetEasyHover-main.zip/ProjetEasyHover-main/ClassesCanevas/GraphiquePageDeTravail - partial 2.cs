﻿using ProjetEasyHover.ClassesStatiques;


namespace ProjetEasyHover.ClassesCanevas
{
    public partial class GraphiquePageDeTravail : IDrawable
    {
        // Permet de trigger un événement dès que la localisation du point objectif est modifiée. Cet événement est écouté par des classes de PageTravailSolOuAir.
        public void setPointLocationObjectif(Location newLocation)
        {
            pointLocationObjectif = newLocation;

            changementPointLocationObjectif?.Invoke(newLocation);
        }



        // Je voulais faire un fond de carte défilant matérialisé par une grille orientée pour mieux faire ressentir les rotations et les déplacements de l'aéronef
        // par rapport au sol mais les pilotes ne trouvaient pas cela pertinent donc fonctionnalitée abandonnée ...
        private void grilleOrientee(ICanvas canvas, RectF dirtyRect)
        {
            canvas.StrokeColor = Colors.Green;


            if (distanceDemiEcran < 50)
            {
                petiteGraduationDistance = 5;
            }
            else if (distanceDemiEcran < 100)
            {
                petiteGraduationDistance = 10;
            }
            else if (distanceDemiEcran < 200)
            {
                petiteGraduationDistance = 20;
            }
            else
            {
                petiteGraduationDistance = 40;
            }


            for (float capouille = capActuelBoussole; capouille <= capActuelBoussole + 90; capouille += 90)
            {
                canvas.StrokeSize = 2;

                float capArranged = FonctionsUtils.remettreAngleEntre0et360(capouille);
                if (capArranged > 180)
                {
                    capArranged -= 180;
                }


                float rayonGrandCercle = (float)Math.Sqrt(2 * (dirtyRect.Width / 2 - OFFSET_BORD_ECRAN) * (dirtyRect.Width / 2 - OFFSET_BORD_ECRAN));
                float deltaX = 0;
                float deltaY = 0;

                if (capArranged <= 45)
                {
                    deltaX = -rayonGrandCercle * (float)Math.Tan((float)FonctionsUtils.conversionDegreeRadians(capArranged, true)) / (float)Math.Sqrt(2);
                    deltaY = -rayonGrandCercle * (float)Math.Sqrt(2) / 2;
                }
                else if (capArranged <= 135)
                {
                    deltaX = -rayonGrandCercle * (float)Math.Sqrt(2) / 2;
                    deltaY = rayonGrandCercle * (float)Math.Tan((float)FonctionsUtils.conversionDegreeRadians(capArranged - 90, true)) / (float)Math.Sqrt(2);
                }
                else
                {
                    deltaX = -rayonGrandCercle * (float)Math.Tan((float)FonctionsUtils.conversionDegreeRadians(180 - capArranged, true)) / (float)Math.Sqrt(2);
                    deltaY = rayonGrandCercle * (float)Math.Sqrt(2) / 2;
                }
                canvas.DrawLine(POINT_CENTRE.X - deltaX, POINT_CENTRE.Y - deltaY, POINT_CENTRE.X + deltaX, POINT_CENTRE.Y + deltaY);
            }





            for (float graduation = 0; graduation <= distanceDemiEcran; graduation += petiteGraduationDistance)
            {
                canvas.StrokeSize = 1;
                if (graduation % (5 * petiteGraduationDistance) == 0)
                {
                    canvas.StrokeSize = 2;
                }


                float coordsParRapportCentre = graduation * (dirtyRect.Width - 2 * OFFSET_BORD_ECRAN) / (2 * distanceDemiEcran);
                if (coordsParRapportCentre <= RAYON_CERCLE_GRADUATIONS_BOUSSOLE)
                {
                    float angle = 90 - FonctionsUtils.conversionDegreeRadians((float)Math.Acos(coordsParRapportCentre / RAYON_CERCLE_GRADUATIONS_BOUSSOLE), false);

                    PointF hautDroite = FonctionsUtils.calculPointF_pointCentreRayonAngleDegree(POINT_CENTRE, RAYON_CERCLE_GRADUATIONS_BOUSSOLE, angle - capActuelBoussole);
                    PointF basDroite = FonctionsUtils.calculPointF_pointCentreRayonAngleDegree(POINT_CENTRE, RAYON_CERCLE_GRADUATIONS_BOUSSOLE, 180 - angle - capActuelBoussole);

                    canvas.DrawLine(hautDroite, basDroite);


                    PointF hautGauche = FonctionsUtils.calculPointF_pointCentreRayonAngleDegree(POINT_CENTRE, RAYON_CERCLE_GRADUATIONS_BOUSSOLE, -angle - capActuelBoussole);
                    PointF basGauche = FonctionsUtils.calculPointF_pointCentreRayonAngleDegree(POINT_CENTRE, RAYON_CERCLE_GRADUATIONS_BOUSSOLE, -180 + angle - capActuelBoussole);

                    canvas.DrawLine(hautGauche, basGauche);



                    PointF lol = FonctionsUtils.calculPointF_pointCentreRayonAngleDegree(POINT_CENTRE, RAYON_CERCLE_GRADUATIONS_BOUSSOLE, angle - capActuelBoussole - 90);
                    PointF lool = FonctionsUtils.calculPointF_pointCentreRayonAngleDegree(POINT_CENTRE, RAYON_CERCLE_GRADUATIONS_BOUSSOLE, 180 - angle - capActuelBoussole - 90);

                    canvas.DrawLine(lol, lool);


                    PointF loool = FonctionsUtils.calculPointF_pointCentreRayonAngleDegree(POINT_CENTRE, RAYON_CERCLE_GRADUATIONS_BOUSSOLE, -angle - capActuelBoussole - 90);
                    PointF looool = FonctionsUtils.calculPointF_pointCentreRayonAngleDegree(POINT_CENTRE, RAYON_CERCLE_GRADUATIONS_BOUSSOLE, -180 + angle - capActuelBoussole - 90);

                    canvas.DrawLine(loool, looool);

                }







                //float coordsParRapportCentre = graduation * (dirtyRect.Width - 2 * offsetBordEcran) / (2 * distanceDemiEcran);
                //canvas.DrawLine(pointCentre.X + coordsParRapportCentre, offsetBordEcran, pointCentre.X + coordsParRapportCentre, dirtyRect.Width - offsetBordEcran);
            }
        }



        private void regleGradueeGraphique(ICanvas canvas, RectF zoneRectangulaireRegle)
        {
            // Faire le fond de la règle graduée
            styleFondregle(canvas);
            canvas.FillRectangle(zoneRectangulaireRegle);

            // Faire la ligne principale de la règle graduée
            styleLigneRegle(canvas);
            canvas.DrawLine(OFFSET_BORD_ECRAN, zoneRectangulaireRegle.Top + 1, zoneRectangulaireRegle.Right - OFFSET_BORD_ECRAN, zoneRectangulaireRegle.Top + 1);


            for (float graduation = 0; graduation <= distanceDemiEcran; graduation += petiteGraduationDistance)
            {
                float tailleGraduation = 7;
                float epaisseurGraduation = 1;

                if (graduation % ((NBR_MAX_GRADUATIONS_DISTANCE - 2) * petiteGraduationDistance) == 0)
                {
                    tailleGraduation *= 2;
                    epaisseurGraduation *= 2;
                }


                float coordsParRapportCentre = graduation * (zoneRectangulaireRegle.Right - 2 * OFFSET_BORD_ECRAN) / (2 * distanceDemiEcran);

                styleGraduationsRegle(canvas, epaisseurGraduation);
                canvas.DrawLine(POINT_CENTRE.X + coordsParRapportCentre, zoneRectangulaireRegle.Top, POINT_CENTRE.X + coordsParRapportCentre, zoneRectangulaireRegle.Top + tailleGraduation);
                canvas.DrawLine(POINT_CENTRE.X - coordsParRapportCentre, zoneRectangulaireRegle.Top, POINT_CENTRE.X - coordsParRapportCentre, zoneRectangulaireRegle.Top + tailleGraduation);

                styleEcritureGraduationsRegle(canvas);
                canvas.DrawString(graduation.ToString(), POINT_CENTRE.X + coordsParRapportCentre, zoneRectangulaireRegle.Top + tailleGraduation + 14, HorizontalAlignment.Center);
                canvas.DrawString(graduation.ToString(), POINT_CENTRE.X - coordsParRapportCentre, zoneRectangulaireRegle.Top + tailleGraduation + 14, HorizontalAlignment.Center);
            }
        }


        private void cadranNumeriqueBoussole(ICanvas canvas)
        {
            // Cercle servant de base au cadran numérique matérialisant la boussole.
            styleCercleCadranNumeriqueBoussole(canvas);
            canvas.DrawCircle(POINT_CENTRE, RAYON_CERCLE_GRADUATIONS_BOUSSOLE);


            // Tout un bordel pour la graduation correspondant au cap actuel devienne plus grande et plus épaisse en temps réel.
            for (int i = 0; i < 360; i++)
            {
                float vraieProportionGraduation = vraieProportionGraduationBoussole(i, capActuelBoussole);

                float vraiTailleGraduation;
                if (i % 30 == 0)
                {
                    vraiTailleGraduation = TAILLE_GRADUATIONS * PROPORTION10;
                }
                else
                {
                    vraiTailleGraduation = TAILLE_GRADUATIONS * vraieProportionGraduation;
                }

                // Epaisseur qui va bien 
                float vraiEpaisseurGraduation = EPAISSEUR_GRADUATIONS * vraieProportionGraduation;

                // Taille qui va bien
                PointF debutGraduation = FonctionsUtils.calculPointF_pointCentreRayonAngleDegree(POINT_CENTRE, RAYON_CERCLE_GRADUATIONS_BOUSSOLE + TAILLE_ECART_CERCLE, i - capActuelBoussole);
                PointF finGraduation = FonctionsUtils.calculPointF_pointCentreRayonAngleDegree(POINT_CENTRE, RAYON_CERCLE_GRADUATIONS_BOUSSOLE + TAILLE_ECART_CERCLE + vraiTailleGraduation, i - capActuelBoussole);


                // Tracer la graduation concernée avec la taille et l'épaisseur qui vont bien
                styleGraduationCourante_bulleOuTrait_CadranNumeriqueBoussole(canvas, vraiEpaisseurGraduation);
                canvas.DrawLine(debutGraduation, finGraduation);


                // Et encore plus de bordel pour mettre des bulles de graduation cliquables tous les 30° de cap
                if (i % 30 == 0)
                {
                    PointF centreCercletexteGraduation = FonctionsUtils.calculPointF_pointCentreRayonAngleDegree(POINT_CENTRE, RAYON_CERCLE_GRADUATIONS_BOUSSOLE + TAILLE_ECART_CERCLE + vraiTailleGraduation + RAYON_TEXTE_GRADUATION, i - capActuelBoussole);

                    // On dessine le cercle de la bulle
                    styleGraduationCourante_bulleOuTrait_CadranNumeriqueBoussole(canvas, vraiEpaisseurGraduation);
                    canvas.DrawCircle(centreCercletexteGraduation, RAYON_TEXTE_GRADUATION);


                    // Puis le texte dans la bulle 
                    RectF rectangleInscrit = new RectF(centreCercletexteGraduation.X - (float)Math.Cos(45.0 * Math.PI / 180.0) * RAYON_TEXTE_GRADUATION, centreCercletexteGraduation.Y - (float)Math.Sin(45.0 * Math.PI / 180.0) * RAYON_TEXTE_GRADUATION, (float)Math.Cos(45.0 * Math.PI / 180.0) * RAYON_TEXTE_GRADUATION * 2, (float)Math.Sin(45.0 * Math.PI / 180.0) * RAYON_TEXTE_GRADUATION * 2);
                    /*
                    canvas.FillColor = Colors.Black;
                    canvas.StrokeColor = Colors.Aqua;
                    canvas.FillRoundedRectangle(rectangleInscrit, 5);
                    */
                    styleStringGraduationBulleCadranNumeriqueBoussole(canvas);
                    canvas.DrawString(i.ToString(), rectangleInscrit, HorizontalAlignment.Center, VerticalAlignment.Center);
                }
            }
        }





        public float vraieProportionGraduationBoussole(int numGraduation, float capActuel)
        {
            float vraieProportionGraduationBoussole = 1;

            if (numGraduation % 10 == 0)
            {
                vraieProportionGraduationBoussole *= PROPORTION10;
            }
            else if (numGraduation % 5 == 0)
            {
                vraieProportionGraduationBoussole *= PROPORTION5;
            }



            // Effet de proximité de focus avec toutes les graduations sauf les grosses bulles de 30
            if (numGraduation == Math.Round(capActuel) && numGraduation % 30 != 0)
            {
                float deltaRound = Math.Abs((float)Math.Round(capActuel) - capActuel);
                vraieProportionGraduationBoussole *= 2 * deltaRound - 2 * PROPORTION_CURRENT * deltaRound + PROPORTION_CURRENT;
            }




            // Effet de procimité de focus pour les grosses bulles de 30 -> commence 10 avant et finit 10 après (plage de 20)
            if (capActuel > 350)
            {
                capActuel = capActuel - 360;
            }
            if (numGraduation >= capActuel - 10 && numGraduation <= capActuel + 10 && numGraduation % 30 == 0)
            {
                float deltaGrosRound = Math.Abs(numGraduation - capActuel);
                vraieProportionGraduationBoussole *= (deltaGrosRound - PROPORTION_CURRENT * deltaGrosRound + 10 * PROPORTION_CURRENT) / (float)10;
            }

            return vraieProportionGraduationBoussole;
        }




        private void affichagePointObjectif(ICanvas canvas, RectF dirtyRect)
        {
            // Appuyer pour faire apparaître le bloc de code peremttant de déterminer distanceMax. J'avoue qu eje ne comprends pas vraiment la logique de ce bloc que j'ai moi-même fait (ToT)
            #region Ce bloc permet de déterminer si le point objectif est hors-cadre ou non. Si hors-cadre, alors les barres de tendance disparaissent et laissent place à la flèche indicatrice 
           
            float capArranged = FonctionsUtils.remettreAngleEntre0et360(angleDegreeObjectif - capActuelBoussole);
            if (capArranged > 180)
            {
                capArranged -= 180;
            }

            // rayon exprimé en pixels
            float rayonGrandCercle = (float)Math.Sqrt(2 * (dirtyRect.Width / 2 - OFFSET_BORD_ECRAN) * (dirtyRect.Width / 2 - OFFSET_BORD_ECRAN));

            // DeltaX et DeltaY sont exprimés en pixels
            float deltaX = 0;
            float deltaY = 0;

            if (capArranged <= 45)
            {
                deltaX = -rayonGrandCercle * (float)Math.Tan((float)FonctionsUtils.conversionDegreeRadians(capArranged, true)) / (float)Math.Sqrt(2);
                deltaY = -rayonGrandCercle * (float)Math.Sqrt(2) / 2;
            }
            else if (capArranged <= 135)
            {
                deltaX = -rayonGrandCercle * (float)Math.Sqrt(2) / 2;
                deltaY = rayonGrandCercle * (float)Math.Tan((float)FonctionsUtils.conversionDegreeRadians(capArranged - 90, true)) / (float)Math.Sqrt(2);
            }
            else
            {
                deltaX = -rayonGrandCercle * (float)Math.Tan((float)FonctionsUtils.conversionDegreeRadians(180 - capArranged, true)) / (float)Math.Sqrt(2);
                deltaY = rayonGrandCercle * (float)Math.Sqrt(2) / 2;
            }

            // Cette variable (exprimée en pixels) permet de déterminer si le point objectif est hors-cadre ou non..
            double distanceMax = Math.Sqrt(deltaX * deltaX + deltaY * deltaY);
            #endregion

            if (distanceObjectif < distanceMax * distanceDemiEcran / (dirtyRect.Width / 2 - OFFSET_BORD_ECRAN))
            {
                bool etatBarresDeTendance_trueNormales_falseDashed = pointLocationObjectif != null && pointLocationAeronef != null;
                PointF pointLocation = FonctionsUtils.calculPointF_pointCentreRayonAngleDegree(POINT_CENTRE, distanceObjectif * ((dirtyRect.Width / 2) - OFFSET_BORD_ECRAN) / distanceDemiEcran, angleDegreeObjectif - capActuelBoussole);

                // Faire les barres de tendance
                styleBarresDeTendance(canvas, etatBarresDeTendance_trueNormales_falseDashed);
                canvas.DrawLine(pointLocation.X, OFFSET_BORD_ECRAN + OFFSET_HAUT_ECRAN, pointLocation.X, dirtyRect.Width - OFFSET_BORD_ECRAN + OFFSET_HAUT_ECRAN);
                canvas.DrawLine(OFFSET_BORD_ECRAN, pointLocation.Y, dirtyRect.Width - OFFSET_BORD_ECRAN, pointLocation.Y);
                canvas.StrokeDashPattern = null; // Pour éviter que le mode pointillés ne se propage


                // Faire les distances si besoin
                if (etatBarresDeTendance_trueNormales_falseDashed)
                {
                    double distanceX = Math.Round(Math.Abs(Math.Sin(FonctionsUtils.conversionDegreeRadians(angleDegreeObjectif - capActuelBoussole, true)) * distanceObjectif));
                    double distanceY = Math.Round(Math.Abs(-Math.Cos(FonctionsUtils.conversionDegreeRadians(angleDegreeObjectif - capActuelBoussole, true)) * distanceObjectif));

                    string stringDistanceX = distanceX.ToString();
                    string stringDistanceY = distanceY.ToString();

                    int nbrDeChiffresX = stringDistanceX.Length;
                    int nbrDeChiffresY = stringDistanceY.Length;

                    float demiLongueurEtiquetteX = 6 * nbrDeChiffresX;
                    float demiLongueurEtiquetteY = 6 * nbrDeChiffresY;

                    // Permet de placer les distances intérieures en haut/bas et à gauche/droite de la croix centrale en fonction de la position du point de référence
                    float coordX_EtiquetteX = pointLocation.X >= POINT_CENTRE.X ? POINT_CENTRE.X + 45 : POINT_CENTRE.X - 45;
                    float coordY_EtiquetteY = pointLocation.Y >= POINT_CENTRE.Y ? POINT_CENTRE.Y + 45 : POINT_CENTRE.Y - 45;

                    RectF rectangleEtiquetteX = new RectF(coordX_EtiquetteX - demiLongueurEtiquetteX, POINT_CENTRE.Y - 9, 2 * demiLongueurEtiquetteX, 18);
                    RectF rectangleEtiquetteY = new RectF(POINT_CENTRE.X - demiLongueurEtiquetteY, coordY_EtiquetteY - 9, 2 * demiLongueurEtiquetteY, 18);


                    // Faire les étiquettes des distances intérieures
                    styleFondDistancesInterieures(canvas);
                    canvas.FillRectangle(rectangleEtiquetteX);
                    canvas.FillRectangle(rectangleEtiquetteY);


                    // Ecrire les distances intérieures
                    styleDistances(canvas);
                    canvas.DrawString(stringDistanceX, rectangleEtiquetteX, HorizontalAlignment.Center, VerticalAlignment.Center);
                    canvas.DrawString(stringDistanceY, rectangleEtiquetteY, HorizontalAlignment.Center, VerticalAlignment.Center);


                    // Ecrire les distancesX aux bouts de la barre de tendance verticale, en haut et en bas du graphique
                    styleDistances(canvas);
                    RectF rectangleHaut = new RectF(pointLocation.X - 50, OFFSET_HAUT_ECRAN, 100, OFFSET_BORD_ECRAN);
                    canvas.DrawString(stringDistanceX, rectangleHaut, HorizontalAlignment.Center, VerticalAlignment.Center);
                    RectF rectangleBas = new RectF(pointLocation.X - 50, OFFSET_HAUT_ECRAN + OFFSET_BORD_ECRAN + dirtyRect.Width - 2 * OFFSET_BORD_ECRAN, 100, OFFSET_BORD_ECRAN);
                    canvas.DrawString(stringDistanceX, rectangleBas, HorizontalAlignment.Center, VerticalAlignment.Center);


                    // Ecrire les distancesY aux bouts de la barre de tendance horizontale, à gauche et à droite du graphique en faisant pivoter les inscriptions si le nombre est trop grand
                    if (nbrDeChiffresY >= 3)
                    {
                        styleDistances(canvas);
                        canvas.Rotate(-90); // Pivotage du repère du canevas
                        RectF rectangleGauche = new RectF(- pointLocation.Y - 50, 0, 100, OFFSET_BORD_ECRAN);
                        canvas.DrawString(stringDistanceY, rectangleGauche, HorizontalAlignment.Center, VerticalAlignment.Center);
                        canvas.Rotate(180);
                        RectF rectangleDroite = new RectF(pointLocation.Y - 50, - dirtyRect.Width, 100, OFFSET_BORD_ECRAN);
                        canvas.DrawString(stringDistanceY, rectangleDroite, HorizontalAlignment.Center, VerticalAlignment.Center);
                        canvas.Rotate(-90);
                    }
                    else
                    {
                        styleDistances(canvas);
                        RectF rectangleGauchePetit = new RectF(0, pointLocation.Y - 50, OFFSET_BORD_ECRAN, 100);
                        canvas.DrawString(stringDistanceY, rectangleGauchePetit, HorizontalAlignment.Center, VerticalAlignment.Center);
                        RectF rectangleDroitePetit = new RectF(dirtyRect.Width - OFFSET_BORD_ECRAN, pointLocation.Y - 50, OFFSET_BORD_ECRAN, 100);
                        canvas.DrawString(stringDistanceY, rectangleDroitePetit, HorizontalAlignment.Center, VerticalAlignment.Center);
                    }
                }
            }
            else
            {
                flecheIndicatrice(canvas, POINT_CENTRE, RAYON_CERCLE_CENTRE_GRAPHIQUE, angleDegreeObjectif - capActuelBoussole);
            }
        }




        private void flecheIndicatrice(ICanvas canvas, PointF pointCentreAffichage, float rayonAffichage, float capAffichage)
        {
            PathF path = new PathF();

            PointF pointe = FonctionsUtils.calculPointF_pointCentreRayonAngleDegree(pointCentreAffichage, rayonAffichage, capAffichage);

            path.MoveTo(pointe.X - 20, pointe.Y + 20);
            path.LineTo(pointe.X, pointe.Y);
            path.LineTo(pointe.X + 20, pointe.Y + 20);
            path = path.Rotate(capAffichage, pointe);

            styleFlecheIndicatrice(canvas);
            canvas.DrawPath(path);



            PointF endroitString = FonctionsUtils.calculPointF_pointCentreRayonAngleDegree(pointCentreAffichage, rayonAffichage - 37, capAffichage);
            double angleRectangleInscrit = 25.0;
            RectF rectangleInscrit = new RectF(endroitString.X - (float)Math.Cos(angleRectangleInscrit * Math.PI / 180.0) * 24, endroitString.Y - (float)Math.Sin(angleRectangleInscrit * Math.PI / 180.0) * 24, (float)Math.Cos(angleRectangleInscrit * Math.PI / 180.0) * 24 * 2, (float)Math.Sin(angleRectangleInscrit * Math.PI / 180.0) * 24 * 2);

            //canvas.StrokeSize = 1;
            //canvas.DrawCircle(endroitString, 24);
            //canvas.DrawRectangle(rectangleInscrit);

            string stringDistanceObjectif = Math.Round(distanceObjectif).ToString();
            if (stringDistanceObjectif.Length > 4)
            {
                stringDistanceObjectif = ">10k";
            }
            styleDistanceObjectifFlecheInidcatrice(canvas, stringDistanceObjectif.Length);
            canvas.DrawString(stringDistanceObjectif, rectangleInscrit, HorizontalAlignment.Center, VerticalAlignment.Center);
        }




        private void lettresPointsCardinaux(ICanvas canvas)
        {
            for (int point = 0; point <= 270; point += 90)
            {
                PointF centreCercleLettre = FonctionsUtils.calculPointF_pointCentreRayonAngleDegree(POINT_CENTRE, RAYON_CERCLE_GRADUATIONS_BOUSSOLE - 20, point - capActuelBoussole);

                //canvas.DrawCircle(centreCercleLettre, 20); 

                RectF rectangleInscrit = new RectF(centreCercleLettre.X - (float)Math.Cos(45.0 * Math.PI / 180.0) * RAYON_TEXTE_GRADUATION, centreCercleLettre.Y - (float)Math.Sin(45.0 * Math.PI / 180.0) * RAYON_TEXTE_GRADUATION, (float)Math.Cos(45.0 * Math.PI / 180.0) * RAYON_TEXTE_GRADUATION * 2, (float)Math.Sin(45.0 * Math.PI / 180.0) * RAYON_TEXTE_GRADUATION * 2);
                canvas.FillRectangle(rectangleInscrit);
                canvas.FontColor = Colors.Red;
                canvas.FontSize = 24;
                canvas.Font = Microsoft.Maui.Graphics.Font.DefaultBold;

                string[] lettres = { "N", "E", "S", "W" };
                canvas.DrawString(lettres[point / 90], rectangleInscrit, HorizontalAlignment.Center, VerticalAlignment.Center);
            }
        }




        private void croixCentrale(ICanvas canvas)
        {
            float longueurEtiquetteCroixCentrale = 23;
            float longueurCroixCentrale = 20;

            styleEtiquetteCroixCentrale(canvas);
            canvas.DrawLine(POINT_CENTRE.X, POINT_CENTRE.Y - longueurEtiquetteCroixCentrale, POINT_CENTRE.X, POINT_CENTRE.Y + longueurEtiquetteCroixCentrale);
            canvas.DrawLine(POINT_CENTRE.X - longueurEtiquetteCroixCentrale, POINT_CENTRE.Y, POINT_CENTRE.X + longueurEtiquetteCroixCentrale, POINT_CENTRE.Y);

            styleCroixCentrale(canvas);
            canvas.DrawLine(POINT_CENTRE.X, POINT_CENTRE.Y - longueurCroixCentrale, POINT_CENTRE.X, POINT_CENTRE.Y + longueurCroixCentrale);
            canvas.DrawLine(POINT_CENTRE.X - longueurCroixCentrale, POINT_CENTRE.Y, POINT_CENTRE.X + longueurCroixCentrale, POINT_CENTRE.Y);


            // Ancienne version de la croix centrale : forme ronde (North-up) ou triangulaire (Heads-up)
            /*
            if (capActuelBoussole == 0)
            {
                canvas.FillColor = Colors.Red;
                canvas.FillEllipse(POINT_CENTRE.X - 20, POINT_CENTRE.Y - 20, 40, 40);
            }
            else
            {
                PathF path = new PathF();

                path.MoveTo(POINT_CENTRE.X - 20, POINT_CENTRE.Y + 20);
                path.LineTo(POINT_CENTRE.X, POINT_CENTRE.Y - 30);
                path.LineTo(POINT_CENTRE.X + 20, POINT_CENTRE.Y + 20);
                path.Close();

                canvas.FillColor = Colors.Red;
                //canvas.StrokeLineJoin = LineJoin.Round;
                canvas.FillPath(path);
            }
            */

        }



        private void afficherTraceClic(ICanvas canvas)
        {
            // Ceci permet de voir combien de temps il faut rester appuyer avant de déclencher un clic long. Cela permet aussi de regler le cap de façon originale mais peu utile en situation réelle...

            if (affichageTraceClic)
            {
                if (clicLongVerrouilled)
                {
                    canvas.StrokeSize = MIN_EPAISSEUR_ARC_CLIC;
                    if (!dragSpecial)
                    {
                        canvas.StrokeColor = Colors.Red;
                    }
                    else
                    {
                        canvas.StrokeColor = Colors.Green;
                        float angleActuel = FonctionsUtils.calculDegreePointB_relatifTo_pointA(pointClic, toucheActuel);
                        PointF pointRepereDragSpecial = FonctionsUtils.calculPointF_pointCentreRayonAngleDegree(pointClic, WIDTH_ARC_CLIC / 2 - RAYON_POINT_REPERE_DRAG_SPECIAL, angleActuel);

                        canvas.FillColor = Colors.Green;
                        canvas.FillCircle(pointRepereDragSpecial, RAYON_POINT_REPERE_DRAG_SPECIAL);
                    }
                }
                else
                {
                    canvas.StrokeColor = Colors.Aqua;
                    canvas.StrokeSize = MIN_EPAISSEUR_ARC_CLIC + progressionClicLong * (MAX_EPAISSEUR_ARC_CLIC - MIN_EPAISSEUR_ARC_CLIC);
                }
                canvas.DrawArc(pointClic.X - WIDTH_ARC_CLIC / 2, pointClic.Y - HEIGHT_ARC_CLIC / 2, WIDTH_ARC_CLIC, HEIGHT_ARC_CLIC, START_ANGLE_ARC_CLIC, START_ANGLE_ARC_CLIC + progressionClicLong * (END_ANGLE_ARC_CLIC - START_ANGLE_ARC_CLIC), false, false);
            }
        }
    }
}

﻿using ProjetEasyHover.ClassesStatiques;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetEasyHover.ClassesCanevas
{
    public class GraphiquePageDeChargement : IDrawable
    {
        public void Draw(ICanvas canvas, RectF dirtyRect)
        {
            ConfigData.tailleX_ecran = dirtyRect.Width;
            ConfigData.tailleY_ecran = dirtyRect.Height;

            canvas.FillColor = Colors.Red;
            canvas.FillRectangle(0, 0, dirtyRect.Width, dirtyRect.Height);

            Console.WriteLine("tailleX_ecran : " + ConfigData.tailleX_ecran);
            Console.WriteLine("tailleY_ecran : " + ConfigData.tailleY_ecran);

            RectF stringBounds = new RectF(dirtyRect.Width / 2 - 80, dirtyRect.Height / 2 - 20, 80 * 2, 20 * 2);
            canvas.FontSize = 50;
            canvas.FontColor = Colors.White;
            canvas.DrawString("Easy Hover", stringBounds, HorizontalAlignment.Center, VerticalAlignment.Center);
        }
    }
}

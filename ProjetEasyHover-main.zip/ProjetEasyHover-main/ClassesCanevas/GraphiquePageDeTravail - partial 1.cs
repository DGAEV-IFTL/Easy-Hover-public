﻿using ProjetEasyHover.ClassesStatiques;
using Color = Microsoft.Maui.Graphics.Color;
using PointF = Microsoft.Maui.Graphics.PointF;
using RectF = Microsoft.Maui.Graphics.RectF;

namespace ProjetEasyHover.ClassesCanevas
{
    public partial class GraphiquePageDeTravail : IDrawable
    {

        #region Attributs paramétrables régissant la forme et le fonctionnement de chacun des éléments dessinés sur le canevas
        public Location pointLocationObjectif { get; private set; } = null;
        public delegate void changeLocEventHandler(Location newLocation);
        public event changeLocEventHandler changementPointLocationObjectif;

        public Location pointLocationAeronef { get; set; } = null;
        public float distanceObjectif { get; private set; } = 0;
        public float angleDegreeObjectif { get; private set; } = 0;
        public bool boolAffichagePointObjectif { get; set; } = false;
        //public bool boolPointObjectifCoherent { get; set; } = false;


        public PointF POINT_CENTRE { get; private set; } = new PointF(20, 20);
        public RectF CADRE_CAP { get; private set; } = new RectF(0, 0, 20, 20);

        public RectF CADRE_SCALE { get; private set; } = new RectF();

        public float RAYON_CERCLE_GRADUATIONS_BOUSSOLE { get; } = 120;
        public float RAYON_CERCLE_CENTRE_GRAPHIQUE { get; private set; } = 0;
        public float capActuelBoussole { get; set; } = 0;


        public PointF pointClic { get; set; } = new PointF(20, 20);
        public bool affichageTraceClic { get; set; } = false;


        public int TEMPS_CLIC_LONG { get; } = 600;
        public int TEMPS_CLIC_COURT { get; } = 200;
        public int TEMPS_ANIMATION_CLIC_LONG { get; } = 20;

        public float WIDTH_ARC_CLIC { get; } = 70;
        public float HEIGHT_ARC_CLIC { get; } = 70;
        public float START_ANGLE_ARC_CLIC { get; } = 0;
        public float END_ANGLE_ARC_CLIC { get; } = 360;
        public float MIN_EPAISSEUR_ARC_CLIC { get; } = 2;
        public float MAX_EPAISSEUR_ARC_CLIC { get; } = 15;


        public float currentEpaisseurArcClic { get; set; } = 5;
        public float progressionClicLong { get; set; } = 0;
        public bool clicLongVerrouilled { get; set; } = false;
        public bool dragSpecial { get; set; } = false;

        public PointF toucheActuel { get; set; } = new PointF();
        public float RAYON_POINT_REPERE_DRAG_SPECIAL { get; } = 7;



        public int NBR_MAX_GRADUATIONS_DISTANCE { get; set; } = 4;
        public float[][] petiteGraduationDistanceUnit { get; set; } = new float[][] { new float[] { 5, 10, 25, 50, 100 }, new float[] { 10, 25, 50, 100, 250 }, new float[] { (float)0.5, 1, 2, 5, 10 } };
        public float pourcentageEchelle { get; set; } = (float)0.35;
        public float petiteGraduationDistance { get; set; } = 20;
        public float distanceDemiEcran { get; set; } = 0;
        public float OFFSET_BORD_ECRAN { get; } = 30;
        public float OFFSET_HAUT_ECRAN { get; set; } = 80;




        public int TEMPS_ANIMATION_TELEPORTATION_BOUSSOLE { get; } = 1000;
        public int NBR_ANIMATIONS_TELEPORTATION_BOUSSOLE { get; } = 100;
        public int currentAnimationTeleportationBoussole { get; set; } = 0;




        public float TAILLE_GRADUATIONS { get; } = (float)4;
        public float EPAISSEUR_GRADUATIONS { get; } = (float)0.7;
        public float TAILLE_ECART_CERCLE { get; } = (float)4;
        public float PROPORTION5 { get; } = (float)1.5;
        public float PROPORTION10 { get; } = (float)2.0;
        public float PROPORTION_CURRENT { get; } = (float)2.5;
        public float RAYON_TEXTE_GRADUATION { get; } = (float)15;



        //public float TAILLE_TOUCHES_CLAVIER_TACTILE { get; } = 90;
        //public float TAILLE_ESPACES_TOUCHES_CLAVIER_TACTILE { get; } = 20;
        public Color COULEUR_GENERALE_ELEMENTS { get; } = Colors.Aqua;
        #endregion

         
        #region Fonctions déterminant le style de chacun des éléments dessinés sur le canevas
        void styleScale(ICanvas canvas)
        {
            canvas.FontColor = COULEUR_GENERALE_ELEMENTS;
            canvas.FontSize = 20;
            canvas.Font = Microsoft.Maui.Graphics.Font.DefaultBold;
        }
        void styleCadreCap(ICanvas canvas)
        {
            canvas.StrokeColor = COULEUR_GENERALE_ELEMENTS;
            canvas.StrokeSize = 3;
        }
        void styleCap(ICanvas canvas)
        {
            canvas.FontColor = COULEUR_GENERALE_ELEMENTS;
            canvas.FontSize = 20;
            canvas.Font = Microsoft.Maui.Graphics.Font.DefaultBold;
        }
        void styleSquareGraphique(ICanvas canvas)
        {
            canvas.FillColor = Colors.Black;
        }
        void styleFondregle(ICanvas canvas)
        {
            canvas.FillColor = Colors.Black;
        }
        void styleLigneRegle(ICanvas canvas)
        {
            canvas.StrokeColor = Colors.Red;
            canvas.StrokeSize = 3;
        }
        void styleGraduationsRegle(ICanvas canvas, float epaisseurGraduation)
        {
            canvas.StrokeColor = Colors.Red;
            canvas.StrokeSize = epaisseurGraduation;
        }
        void styleEcritureGraduationsRegle(ICanvas canvas)
        {
            canvas.FontColor = Colors.Aqua;
            canvas.FontSize = 15;
            canvas.Font = Microsoft.Maui.Graphics.Font.DefaultBold;
        }
        void styleBarresDeTendance(ICanvas canvas, bool trueNormales_falseDashed)
        {
            if (trueNormales_falseDashed)
            {
                canvas.StrokeDashPattern = null;
            }
            else
            {
                canvas.StrokeDashPattern = new float[] { 2, 2 };
            }

            canvas.StrokeColor = Colors.Yellow;
            canvas.StrokeSize = 3;
        }
        void styleDistances(ICanvas canvas)
        {
            canvas.FontSize = 20;
            canvas.FontColor = Colors.Yellow;
            canvas.Font = Microsoft.Maui.Graphics.Font.DefaultBold;
        }
        void styleFondDistancesInterieures(ICanvas canvas)
        {
            canvas.FillColor = Colors.Black;
        }
        void styleDistanceObjectifPermanente(ICanvas canvas)
        {
            canvas.FontColor = Colors.Aqua;
            canvas.FontSize = 15;
        }
        void styleFlecheIndicatrice(ICanvas canvas)
        {
            canvas.StrokeSize = 5;
            canvas.StrokeColor = Colors.Yellow;
            canvas.StrokeLineJoin = LineJoin.Round;
        }
        void styleDistanceObjectifFlecheInidcatrice(ICanvas canvas, int nbrDigits)
        {
            canvas.Font = Microsoft.Maui.Graphics.Font.DefaultBold;
            canvas.FontColor = Colors.Yellow;

            if(nbrDigits >= 4)
            {
                canvas.FontSize = 18;
            }
            else if(nbrDigits >= 3)
            {
                canvas.FontSize = 25;
            }
            else
            {
                canvas.FontSize = 30;
            }
        }
        void styleCercleCadranNumeriqueBoussole(ICanvas canvas)
        {
            canvas.StrokeColor = Colors.Aqua;
            canvas.StrokeSize = 1;
        }

        void styleCercleCentralDelimitantLeClicPlot(ICanvas canvas)
        {
            canvas.StrokeColor = Colors.Aqua;
            canvas.StrokeSize = 2;
        }

        void styleGraduationCourante_bulleOuTrait_CadranNumeriqueBoussole(ICanvas canvas, float vraieEpaisseurGraduation)
        {
            canvas.StrokeSize = vraieEpaisseurGraduation;
            canvas.StrokeColor = Colors.Aqua;
        }

        void styleStringGraduationBulleCadranNumeriqueBoussole(ICanvas canvas)
        {
            canvas.FontColor = Colors.Aqua;
            canvas.FontSize = 12;
        }

        void styleEtiquetteCroixCentrale(ICanvas canvas)
        {
            canvas.StrokeColor = Colors.Black;
            canvas.StrokeSize = 6;
        }

        void styleCroixCentrale(ICanvas canvas)
        {
            canvas.StrokeColor = Colors.Red;
            canvas.StrokeSize = 3;
        }
        #endregion


        // Méthode maîtresse de la classe Canevas : le Draw() qui permet de dessiner les éléments souhaités.
        public void Draw(ICanvas canvas, RectF dirtyRect)
        {
            // L'application n'avait jusqu'à maintenant pas encore récupéré les données de taille du canevas (directement dépendant de la taille de l'écran de l'appareil).
            // Ces données sont stockées automatiquement dans le RectF "dirtyRect". Maintenant qu'il est à disposition, on redéclare quelques constantes qui seront utiles pour la suite :
            CADRE_SCALE = new RectF(dirtyRect.Width / 2 - 150, 5, 300, 25);
            CADRE_CAP = new RectF(dirtyRect.Width / 2 - 60, 40, 120, 35);
            POINT_CENTRE = new PointF(dirtyRect.Width / 2, dirtyRect.Width / 2 + OFFSET_HAUT_ECRAN);
            RAYON_CERCLE_CENTRE_GRAPHIQUE = (dirtyRect.Width - 2 * OFFSET_BORD_ECRAN) / 4; // Quand une barre de tendance est tangente au cercle du centre du graphique, alors la distance indiquée par cette barre de tendance est de la moitié de l'échelle en vigueur.


            // Equations de calcul pour exploiter la localisation actuelle et la localisation objectif
            if (pointLocationObjectif != null && pointLocationAeronef != null)
            {
                distanceObjectif = (float)(Location.CalculateDistance(pointLocationObjectif, pointLocationAeronef, DistanceUnits.Kilometers) * 1000);
                angleDegreeObjectif = FonctionsUtils.conversionDegreeRadians((float)ConvertUnit.CoordinatesDD_ToRadiansAzimut(pointLocationAeronef.Latitude, pointLocationAeronef.Longitude, pointLocationObjectif.Latitude, pointLocationObjectif.Longitude), false);
            }


            // Au cas où
            capActuelBoussole = FonctionsUtils.remettreAngleEntre0et360(capActuelBoussole);
            distanceObjectif = ConvertUnit.majDistanceUnit(distanceObjectif);


            // On détermine les graduations à afficher sur la règle graduée
            float[] unitConcerned = petiteGraduationDistanceUnit[ConfigData.paramDistanceUnit_0m_1ft_2km];
            float maxDistanceDemiEcran = NBR_MAX_GRADUATIONS_DISTANCE * unitConcerned[unitConcerned.Length - 1];
            distanceDemiEcran = pourcentageEchelle * maxDistanceDemiEcran;
            int leBonIndicegraduationDistance = 0;
            while (distanceDemiEcran > NBR_MAX_GRADUATIONS_DISTANCE * unitConcerned[leBonIndicegraduationDistance])
            {
                leBonIndicegraduationDistance++;
            }
            petiteGraduationDistance = unitConcerned[leBonIndicegraduationDistance];


            // Ecrire les informations d'échelle en haut du canevas
            String[] stringDistanceUnit = new string[] { "Meters", "Feets", "Kilometers" };
            string afficheurScale = "SCALE : 0 - " + Math.Round(distanceDemiEcran).ToString() + " " + stringDistanceUnit[ConfigData.paramDistanceUnit_0m_1ft_2km];
            styleScale(canvas);
            canvas.DrawString(afficheurScale, CADRE_SCALE, HorizontalAlignment.Center, VerticalAlignment.Center);

            // Faire le cadre de l'affichage du cap juste en-dessous
            styleCadreCap(canvas);
            canvas.DrawRectangle(CADRE_CAP);

            // Ecrire le cap dans le cadre prévu à cet effet
            styleCap(canvas);
            canvas.DrawString(" " + Math.Round(FonctionsUtils.remettreAngleEntre0et360(capActuelBoussole)).ToString() + "°", CADRE_CAP, HorizontalAlignment.Center, VerticalAlignment.Center);

            // Faire le carré uni servant de fond de carte au graphique
            styleSquareGraphique(canvas);
            canvas.FillRectangle(OFFSET_BORD_ECRAN, OFFSET_HAUT_ECRAN + OFFSET_BORD_ECRAN, dirtyRect.Width - 2 * OFFSET_BORD_ECRAN, dirtyRect.Width - 2 * OFFSET_BORD_ECRAN);

            // Faire la regle graduée 
            regleGradueeGraphique(canvas, new RectF(0, OFFSET_HAUT_ECRAN + OFFSET_BORD_ECRAN + (dirtyRect.Width - 2 * OFFSET_BORD_ECRAN) + OFFSET_BORD_ECRAN, dirtyRect.Width, OFFSET_BORD_ECRAN));

            // Ecrire la distance objectif tout en bas de façon permanente
            styleDistanceObjectifPermanente(canvas);
            float debutHauteurRestante = OFFSET_HAUT_ECRAN + OFFSET_BORD_ECRAN + (dirtyRect.Width - 2 * OFFSET_BORD_ECRAN) + OFFSET_BORD_ECRAN + OFFSET_BORD_ECRAN;
            float hauteurRestante = dirtyRect.Height - debutHauteurRestante;
            RectF cadreDistanceObjectifPermanente = new RectF(0, debutHauteurRestante, dirtyRect.Width, hauteurRestante);
            string stringDistanceObjectif = "Distance to SetPoint : " + Math.Round(distanceObjectif).ToString() + " " + stringDistanceUnit[ConfigData.paramDistanceUnit_0m_1ft_2km];
            canvas.DrawString(stringDistanceObjectif, cadreDistanceObjectifPermanente, HorizontalAlignment.Center, VerticalAlignment.Center);

            // Faire le cercle central délimitant le clic pour plot
            styleCercleCentralDelimitantLeClicPlot(canvas);
            canvas.DrawCircle(POINT_CENTRE, RAYON_CERCLE_CENTRE_GRAPHIQUE);

            // Faire le cadran numérique servant de boussole
            cadranNumeriqueBoussole(canvas);

            // Si l'affichage du point objectif est activé, alors affichage des barres de tendance ou alors de la flèche indicatrice si le point est hors-cadre
            if (boolAffichagePointObjectif)
            {
                affichagePointObjectif(canvas, dirtyRect);
            }

            // Ecriture des points cardinaux un plan à l'avant de l'affichage du point objectif
            lettresPointsCardinaux(canvas);

            // Affichage de la croix centrale un plan à l'avant de l'affichage du point objectif
            croixCentrale(canvas);

            // Affiche lors du maintien d'un clic un témoin de chargement à l'endroit du clic. Quand le témoin de chargement est complété, alors il y a une petite
            // vibration et un clic long a été effectué. Tout en maintenant la pression, si on sort le doigt du cercle affiché, alors on entre dans le mode "dragSpecial"
            // qui permet de règler le cap de manière originale mais peu utile.
            afficherTraceClic(canvas);
        }
    }
}

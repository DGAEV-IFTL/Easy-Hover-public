﻿using ProjetEasyHover.ClassesCanevas;
using ProjetEasyHover.ClassesDiverses;
using ProjetEasyHover.ClassesStatiques;
using System;
using System.Timers;

namespace ProjetEasyHover
{
    public partial class PageTravailSolOuAir : ContentPage
    {
        DispositionPageDeTravail disp = new DispositionPageDeTravail();

        Location coordsEntreesAuClavier = null;


        // Le nécessaire pour faire le chrono
        System.Diagnostics.Stopwatch Stopwatch = new System.Diagnostics.Stopwatch();
        System.Timers.Timer timerMajChrono;



        private CancellationTokenSource _cancelTokenSource;
        private bool _isCheckingLocation;
        //private bool _isSearchingPlot;

        private bool surveillanceGeolocalisation = false;

        private bool enModeClavierTactile = false; // Pour empecher le bouton retour en arriere quand c'est en mode clavier Tactile


        public PageTravailSolOuAir()
        {
            Shell.SetNavBarIsVisible(this, false);
            BackgroundColor = Colors.White;


            timerMajChrono = new System.Timers.Timer(TimeSpan.FromSeconds(1));
            timerMajChrono.Elapsed += TimerMajChrono_Elapsed;


            initTimersEtInteractionsCanevas();


            disp.boutonRetour.ClicCourt += BoutonRetour_ClicCourt;
            disp.boutonRetour.ClicLong += BoutonRetour_ClicLong;
            disp.boutonCoords.ClicCourt += BoutonCoords_ClicCourt;
            disp.boutonCoords.ClicLong += BoutonCoords_ClicLong;
            disp.boutonChrono.ClicCourt += BoutonChrono_ClicCourt;
            disp.boutonChrono.ClicLong += BoutonChrono_ClicLong;
            disp.switchGeoTrackingOnOff.Toggled += SwitchGeoTrackingOnOff_Toggled;
            disp.switchModeCapTrueAuto_falseManuel.Toggled += SwitchModeCapTrueAuto_falseManuel_Toggled;
            disp.fondEnsembleGeoTracking.Clicked += FondEnsembleGeoTracking_Clicked;
            disp.fondEnsembleCaptracking.Clicked += FondEnsembleCaptracking_Clicked;
            disp.objetGraphiqueEasyHover.changementPointLocationObjectif += ObjetGraphiqueEasyHover_changementPointLocationObjectif;

            Content = disp.grillePageDeTravail;
        }

        private async void BoutonRetour_ClicLong(object sender, EventArgs e)
        {
            ConfigData.trueStationnaireSol_falseStationnaireAir = !ConfigData.trueStationnaireSol_falseStationnaireAir;

            await Shell.Current.GoToAsync("PageTravailSolOuAir");
            Navigation.RemovePage(this);
        }

        private void ObjetGraphiqueEasyHover_changementPointLocationObjectif(Location newLocation)
        {
            string lat = "Lat : ";
            string lon = "Lon : ";

            if (newLocation != null)
            {
                if (ConfigData.paramCoordinatesNotation_0DD_1DDM_2DMS == 0)
                {
                    lat += Math.Round(newLocation.Latitude, 6).ToString() + "°";
                    lon += Math.Round(newLocation.Longitude, 6).ToString() + "°";
                }
                else if (ConfigData.paramCoordinatesNotation_0DD_1DDM_2DMS == 1)
                {
                    string[] tabCoordsDDM = ConvertUnit.coordinatesDD_ToCoordinatesDDM(newLocation);
                    lat += tabCoordsDDM[0];
                    lon += tabCoordsDDM[1];
                }
                else if (ConfigData.paramCoordinatesNotation_0DD_1DDM_2DMS == 2)
                {
                    string[] tabCoordsDMS = ConvertUnit.coordinatesDD_ToCoordinatesDMS(newLocation);
                    lat += tabCoordsDMS[0];
                    lon += tabCoordsDMS[1];
                }
                else
                {
                    lat += "ERROR";
                    lon += "ERROR";
                }
            }
            else
            {
                lat += "None";
                lon += "None";
            }

            disp.lblLatitude.Text = lat;
            disp.lblLongitude.Text = lon;

            Console.WriteLine("change location");

        }



        protected override void OnDisappearing()
        {
            base.OnDisappearing();
            Console.WriteLine("On disappearing");

            arreterProcedures();
        }


        private void arreterProcedures()
        {
            // arreter surveillance du compas
            if (Compass.Default.IsSupported)
            {
                if (Compass.Default.IsMonitoring)
                {
                    Compass.Default.Stop();
                }
            }

            // arreter chrono
            timerMajChrono.Stop();
            Stopwatch.Stop();

            // arreter géoloc
        }


        protected override bool OnBackButtonPressed()
        {
            if (enModeClavierTactile)
            {
                return true; // pour empêcher le fonctionnement du bouton retour sur la page d'accueil
            }
            else
            {
                return base.OnBackButtonPressed();
            }
        }

        private async void BoutonRetour_ClicCourt(object sender, EventArgs e)
        {
            await Navigation.PopAsync();
        }





        private void FondEnsembleCaptracking_Clicked(object sender, EventArgs e)
        {
            disp.switchModeCapTrueAuto_falseManuel.IsToggled = !disp.switchModeCapTrueAuto_falseManuel.IsToggled;
        }

        private void FondEnsembleGeoTracking_Clicked(object sender, EventArgs e)
        {
            disp.switchGeoTrackingOnOff.IsToggled = !disp.switchGeoTrackingOnOff.IsToggled;
        }

        private void BoutonCoords_ClicCourt(object sender, EventArgs e)
        {
            // Fonctionnalité malheureusement pas encore aboutie ... 

            /*
            int entrerCoords = 1;
            demanderCreationClavierTactile(entrerCoords);
            */
        }

        private void demanderCreationClavierTactile(int modeClavierTactile_0cap_1coords_2forceVent_3directionVent)
        {
            DispositionClavierTactile clavier = new DispositionClavierTactile(modeClavierTactile_0cap_1coords_2forceVent_3directionVent);
            clavier.Abandon += Clavier_Abandon;
            clavier.Validation += Clavier_Validation;

            Content = clavier.grilleClaviertactile;

            enModeClavierTactile = true;
        }

        private void BoutonCoords_ClicLong(object sender, EventArgs e)
        {
            disp.objetGraphiqueEasyHover.setPointLocationObjectif(null);
            if (disp.switchGeoTrackingOnOff.IsToggled)
            {
                disp.switchGeoTrackingOnOff.IsToggled = false;
            }
            else
            {
                arreterTrackingArreterAffichage();
            }
        }


        private void arreterTrackingArreterAffichage()
        {
            disp.objetGraphiqueEasyHover.boolAffichagePointObjectif = false;
            surveillanceGeolocalisation = false;
            disp.objetGraphiqueEasyHover.pointLocationAeronef = null;
            CancelRequest();



            disp.monCanevas.Invalidate();
        }


        private void BoutonChrono_ClicCourt(object sender, EventArgs e)
        {
            if (Stopwatch.IsRunning)
            {
                Stopwatch.Stop();
                timerMajChrono.Stop();
            }
            else
            {
                Stopwatch.Start();
                timerMajChrono.Start();
            }
            MajTexteChrono(); // Pour avoir un retour immédiat
        }

        private void BoutonChrono_ClicLong(object sender, EventArgs e)
        {
            Stopwatch.Reset();
            timerMajChrono.Stop();
            MajTexteChrono();
        }

        private void TimerMajChrono_Elapsed(object sender, ElapsedEventArgs e)
        {
            Console.WriteLine("timerMajChronoElapsed !!!!");
            MajTexteChrono();
        }

        private void MajTexteChrono()
        {
            Dispatcher.Dispatch(() =>
            {
                if (Stopwatch.IsRunning || Stopwatch.ElapsedMilliseconds != 0)
                {
                    disp.boutonChrono.Text = Stopwatch.Elapsed.ToString("hh\\:mm\\:ss");

                    disp.boutonChrono.TextColor = Stopwatch.IsRunning ? Colors.Black : Colors.Red;
                }
                else
                {
                    disp.boutonChrono.TextColor = Colors.Black;
                    disp.boutonChrono.Text = "CHRONO";
                }
            });
        }

        private void SwitchGeoTrackingOnOff_Toggled(object sender, ToggledEventArgs e)
        {
            if (disp.switchGeoTrackingOnOff.IsToggled)
            {
                if (disp.objetGraphiqueEasyHover.pointLocationObjectif == coordsEntreesAuClavier && disp.objetGraphiqueEasyHover.pointLocationObjectif != null)
                {
                    Console.WriteLine("insane");
                    lancerGeoTracking();
                }
                else
                {
                    plotClicked();
                }
            }
            else
            {
                arreterTrackingArreterAffichage();
            }

            // MajTexteSwitchGeoTracking();
            disp.lblTrackingOnOff.Text = disp.switchGeoTrackingOnOff.IsToggled ? "STOP\n" : "START\n";
        }

        /*
        private void MajTexteSwitchGeoTracking()
        {
            int indexOfSwitch = (disp.switchGeoTrackingOnOff.Parent as Grid).Children.IndexOf(disp.switchGeoTrackingOnOff);

            ((disp.switchGeoTrackingOnOff.Parent as Grid).Children[indexOfSwitch + 1] as Label).Text = disp.switchGeoTrackingOnOff.IsToggled ? "On" : "Off";
        }
        */

        private void SwitchModeCapTrueAuto_falseManuel_Toggled(object sender, ToggledEventArgs e)
        {

            gererSurveillanceBoussole(e.Value);

            int indexOfSwitch = ((sender as Switch).Parent as Grid).Children.IndexOf(disp.switchModeCapTrueAuto_falseManuel);

            (((sender as Switch).Parent as Grid).Children[indexOfSwitch + 1] as Label).Text = e.Value ? "Auto" : "Manuel";
            //((Label)((Grid)((Switch)sender).Parent).Children[2]).Text = e.Value ? "Auto" : "Manuel";

        }

        private void capRegledManuellement()
        {
            if (disp.switchModeCapTrueAuto_falseManuel.IsToggled)
            {
                disp.switchModeCapTrueAuto_falseManuel.IsToggled = false;
            }
        }

        private void gererSurveillanceBoussole(bool trueActiver_falseDesactiver)
        {
            if (Compass.Default.IsSupported)
            {
                if (trueActiver_falseDesactiver)
                {
                    if (!Compass.Default.IsMonitoring)
                    {
                        Compass.Default.ReadingChanged += Default_ReadingChanged;
                        Compass.Default.Start(SensorSpeed.UI);
                    }
                }
                else
                {
                    if (Compass.Default.IsMonitoring)
                    {
                        Compass.Default.ReadingChanged -= Default_ReadingChanged;
                        Compass.Default.Stop();
                    }
                }
            }
        }

        private void Default_ReadingChanged(object sender, CompassChangedEventArgs e)
        {
            //var objetCanevas = (ClockDrawable)ClockGraphicsView.Drawable;
            Console.WriteLine("compass : " + e.Reading);
            disp.objetGraphiqueEasyHover.capActuelBoussole = (float)e.Reading.HeadingMagneticNorth;
            disp.monCanevas.Invalidate();
        }


        private void BoutonCap_Clicked()
        {
            int entrerCap = 0;
            demanderCreationClavierTactile(entrerCap);
        }

        private void Clavier_Validation(object sender, EventArgs e)
        {
            (sender as DispositionClavierTactile).Abandon -= Clavier_Abandon;
            (sender as DispositionClavierTactile).Validation -= Clavier_Validation;

            ValidationEventArgs validationEventArgs = (ValidationEventArgs)e;
            int modeClavierTactile = validationEventArgs.modeClavierTactile_0cap_1coords_2forceVent_3directionVent;

            if (modeClavierTactile == 0)
            {
                teleporterBoussoleAvecAnimation(validationEventArgs.capSaisieUtilisateur);
            }
            else if (modeClavierTactile == 1)
            {
                coordsEntreesAuClavier = validationEventArgs.coordsSaisieUtilisateur;

                if (disp.switchGeoTrackingOnOff.IsToggled)
                {
                    if (disp.chargementPlot.IsRunning)
                    {
                        CancelRequest();
                        disp.objetGraphiqueEasyHover.setPointLocationObjectif(coordsEntreesAuClavier);
                        disp.monCanevas.Invalidate();
                        Console.WriteLine("touched annuled isSearchingPlot");
                    }
                    else
                    {
                        disp.objetGraphiqueEasyHover.setPointLocationObjectif(coordsEntreesAuClavier);
                        disp.monCanevas.Invalidate();
                        Console.WriteLine("touched");
                    }
                }
                else
                {
                    disp.objetGraphiqueEasyHover.setPointLocationObjectif(coordsEntreesAuClavier);
                    disp.switchGeoTrackingOnOff.IsToggled = true;
                }

            }
            else if (modeClavierTactile == 2)
            {
                // [à FAIRE pour mode stationnaire air]
                // validationEventArgs.forceVentSaisieUtilisateur
            }
            else if (modeClavierTactile == 3)
            {
                // [à FAIRE pour mode stationnaire air]
                // validationEventArgs.directionVentSaisieUtilisateur
            }
            else
            {
                // impossible car exception lancée dans constructeur de la classe ValidationEventArgs
            }

            Content = disp.grillePageDeTravail;

            enModeClavierTactile = false;
        }

        private void Clavier_Abandon(object sender, EventArgs e)
        {
            (sender as DispositionClavierTactile).Abandon -= Clavier_Abandon;
            (sender as DispositionClavierTactile).Validation -= Clavier_Validation;

            Content = disp.grillePageDeTravail;

            enModeClavierTactile = false;
        }

        private void LblDist_Clicked(object sender, EventArgs e)
        {
            //countSamere++;
            Button bouton = (Button)sender;
            //bouton.Text = countSamere.ToString();


            //GetCurrentLocation(false);

        }

        private async void plotClicked()
        {

            //Location locationPloted = new Location();
            if (surveillanceGeolocalisation)
            {
                surveillanceGeolocalisation = false;
                CancelRequest();
                //Console.WriteLine("allez c'est parti");
                //Console.WriteLine("allez c'est fini");
                Console.WriteLine("sale impatient");
            }

            disp.chargementPlot.IsRunning = true;
            disp.monCanevas.Invalidate();
            await GetCurrentLocation(true);

            disp.chargementPlot.IsRunning = false;

            lancerGeoTracking();
        }

        private async void lancerGeoTracking()
        {
            int i = 0;
            surveillanceGeolocalisation = true;
            disp.objetGraphiqueEasyHover.boolAffichagePointObjectif = true;
            //disp.lblNbrDeGeolocs.Text = i.ToString();
            disp.monCanevas.Invalidate();


            while (surveillanceGeolocalisation)
            {
                i++;
                await GetCurrentLocation(false);
                //disp.lblNbrDeGeolocs.Text = i.ToString();
                Console.WriteLine("i : " + i);
            }
            Console.WriteLine("lancer surveillance fini");
        }

        public async Task GetCurrentLocation(bool truePloter_falseRecupererPosition)
        {
            try
            {
                GeolocationRequest request = new GeolocationRequest(GeolocationAccuracy.Best, TimeSpan.FromSeconds(10));
                _isCheckingLocation = true;
                _cancelTokenSource = new CancellationTokenSource();

                Console.WriteLine("GOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO !");
                Location location = await Geolocation.Default.GetLocationAsync(request, _cancelTokenSource.Token);
                if (!_cancelTokenSource.IsCancellationRequested)
                {
                    if (location != null)
                    {
                        if (truePloter_falseRecupererPosition)
                        {
                            disp.objetGraphiqueEasyHover.setPointLocationObjectif(location);
                        }
                        else
                        {
                            disp.objetGraphiqueEasyHover.pointLocationAeronef = location;
                        }

                        double distance = Location.CalculateDistance(disp.objetGraphiqueEasyHover.pointLocationObjectif, location, DistanceUnits.Kilometers);
                        Console.WriteLine($"Latitude: {location.Latitude}, Longitude: {location.Longitude}, Course: {location.Course}");
                        Console.WriteLine("miam !");
                        //disp.boxBas.Color = disp.boxBas.Color != Colors.Gray ? Colors.Gray : Colors.Blue;
                        disp.frameIndicatricePrecisionEtTemoinAcquisitionGeoloc.Color = disp.frameIndicatricePrecisionEtTemoinAcquisitionGeoloc.Color != Colors.White ? Colors.White : Colors.Black;
                        disp.monCanevas.Invalidate();
                        Console.WriteLine("OKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK !");
                    }
                }

                Console.WriteLine("FINIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII !");
            }
            // Catch one of the following exceptions:
            //   FeatureNotSupportedException
            //   FeatureNotEnabledException
            //   PermissionException

            catch (FeatureNotEnabledException fneEx)
            {
                // Handle not enabled on device exception
                Console.WriteLine(fneEx.Message);
                await DisplayAlert("Not Enabled !", "The Geolocation feature is not enabled on your device", "OK");
            }
            catch (PermissionException pEx)
            {
                // Handle permission exception
                Console.WriteLine(pEx.Message);
                await DisplayAlert("Not Permitted !", "The Geolocation feature is not permitted on your device", "OK");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("MEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEERDE !");
            }
            finally
            {
                _isCheckingLocation = false;

                Console.WriteLine("is checking false");
            }
        }

        public void CancelRequest()
        {
            if (_isCheckingLocation && _cancelTokenSource != null && _cancelTokenSource.IsCancellationRequested == false)
            {

                Console.WriteLine("go cancel");
                _cancelTokenSource.Cancel();
                Console.WriteLine("cancelled");
            }
        }



        ~PageTravailSolOuAir()
        {
            Console.WriteLine("Destruction page de travail !!");
        }

        private async void boutonRetour_clicked(object sender, EventArgs e)
        {
            await Shell.Current.GoToAsync("PageAccueil");
        }
    }
}

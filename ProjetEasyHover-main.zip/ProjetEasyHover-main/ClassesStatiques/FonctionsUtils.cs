﻿

namespace ProjetEasyHover.ClassesStatiques
{
    public static class FonctionsUtils
    {
        public static float calculDegreePointB_relatifTo_pointA(PointF pointA, PointF pointB)
        {
            float calculDegree = 0;

            float deltaX = pointB.X - pointA.X;
            float deltaY = pointB.Y - pointA.Y;


            if (deltaX != 0)
            {
                float tosa = deltaY / deltaX;
                float angleDegreesBrut = (float)(Math.Atan(tosa) * 180.0 / Math.PI);

                if (deltaX >= 0 && deltaY >= 0)
                {
                    calculDegree = angleDegreesBrut + 90;
                }
                else if (deltaX >= 0 && deltaY < 0)
                {
                    calculDegree = angleDegreesBrut + 90;
                }
                else if (deltaX < 0 && deltaY >= 0)
                {
                    calculDegree = angleDegreesBrut + 270;
                }
                else
                {
                    calculDegree = angleDegreesBrut + 270;
                }
            }
            else
            {
                if (deltaY >= 0)
                {
                    calculDegree = 180;
                }
                else
                {
                    calculDegree = 0;
                }
            }

            return calculDegree;
        }


        public static float calculDistancePoints(PointF pointA, PointF pointB)
        {
            float deltaX = pointB.X - pointA.X;
            float deltaY = pointB.Y - pointA.Y;
            float hypothénuse = (float)Math.Sqrt(deltaX * deltaX + deltaY * deltaY);

            return hypothénuse;
        }



        public static PointF calculPointF_pointCentreRayonAngleDegree(PointF pointCentre, float rayon, float angleDegree)
        {

            float anglePI = (float)((angleDegree - 90) * Math.PI / 180.0);
            float valeurX = (float)Math.Cos(anglePI);
            float valeurY = (float)Math.Sin(anglePI);

            PointF pointCalculed = new PointF(pointCentre.X + valeurX * rayon, pointCentre.Y + valeurY * rayon);

            return pointCalculed;
        }


        public static float remettreAngleEntre0et360(float angle)
        {
            while (angle < 0)
            {
                angle += 360;
            }

            while (angle >= 360)
            {
                angle -= 360;
            }

            return angle;
        }

        public static float cheminLePlusCourtPourAllerDeAngleA_toAngleB(float angleA, float angleB)
        {
            angleA = remettreAngleEntre0et360(angleA);
            angleB = remettreAngleEntre0et360(angleB);


            float cheminPlusCourt = angleB - angleA; // entre -A et 360 - A

            if (cheminPlusCourt <= -180)
            {
                cheminPlusCourt += 360;
            }

            if (cheminPlusCourt > 180)
            {
                cheminPlusCourt -= 360;
            }

            return cheminPlusCourt;
        }

        public static float conversionDegreeRadians(float trueDegree_falseRadians, bool trueDegreeToRadians_falseRadiansToDegree)
        {
            float resultatConverted = trueDegree_falseRadians * 180 / (float)Math.PI;

            if (trueDegreeToRadians_falseRadiansToDegree)
            {
                resultatConverted = trueDegree_falseRadians * (float)Math.PI / 180;
            }

            return resultatConverted;
        }

        public static float conversionPixelsDistance(float truePixels_falseDistance, float distanceDemiEcran, float pixelsDemiEcran, bool truePixelsToDistance_falseDistanceToPixels)
        {
            float resultatConverted = truePixels_falseDistance * pixelsDemiEcran / distanceDemiEcran;

            if (truePixelsToDistance_falseDistanceToPixels)
            {
                resultatConverted = truePixels_falseDistance * distanceDemiEcran / pixelsDemiEcran;
            }

            return resultatConverted;
        }

        public static float tanOpposee(float angleDegree)
        {
            return (float)Math.Tan(FonctionsUtils.conversionDegreeRadians(angleDegree, true)) / (float)Math.Sqrt(2);
        }
    }

}

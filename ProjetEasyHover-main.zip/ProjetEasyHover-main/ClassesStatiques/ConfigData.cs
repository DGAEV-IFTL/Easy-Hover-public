﻿

namespace ProjetEasyHover.ClassesStatiques
{
    public static class ConfigData
    {
        public static bool trueStationnaireSol_falseStationnaireAir { get; set; } = true;
        // public static bool trueCapAuto_falseCapManuel { get; set; } = false;
        public static Color paramCouleurRandom { get; set; } = Colors.Wheat;

        public static float dureeClicLongEnMillisecondes { get; set; } = 800;

        public static float tailleX_ecran { get; set; } = 0;
        public static float tailleY_ecran { get; set; } = 0;

        public static int paramDistanceUnit_0m_1ft_2km { get; set; } = 0;
        public static int paramCoordinatesNotation_0DD_1DDM_2DMS { get; set; } = 0;

    }
}

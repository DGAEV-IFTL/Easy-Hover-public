﻿

namespace ProjetEasyHover.ClassesStatiques
{
    public static class ConvertUnit
    {

        const double twoPi = 2.0 * Math.PI;
        const double totalDegrees = 360.0;
        const double atmospherePascals = 101325.0;
        const double degreesToRadians = Math.PI / 180.0;
        const double milesToKilometers = 1.609344;
        const double milesToMeters = 1609.344;
        const double kilometersToMiles = 1.0 / milesToKilometers;
        const double celsiusToKelvin = 273.15;
        const double poundsToKg = 0.45359237;
        const double poundsToStones = 0.07142857;
        const double stonesToPounds = 14;
        const double kgToPounds = 2.204623;


        const double meanEarthRadiusInKilometers = 6371.0;

        const double internationalFootDefinition = 0.3048;
        const double usSurveyFootDefinition = 1200.0 / 3937;

        //me
        const double kmhtoKt = 0.53997;
        const double kttokmh = 1.851954738226198;
        const double kttometerpars = 0.51444;
        const double meterparstokt = 1.943844;
        const double kmhtometerpars = 0.277778;
        const double meterparstoKmh = 3.6;
        const double meterToKm = .001;
        const double meterToKt = 0.000539957;
        const double kmeterTometer = 1000;
        const double kmeterToNM = 0.539957;
        const double nmTometer = 1852;
        const double nmToKmeter = 1.852;

        const double metersToFeet = 3.28084;
        const double feetToMeters = 0.3048;

        const double kilometersToFeet = 3280.84;
        const double feetToKilometers = 0.0003048;



        public static double NmTometer(double Distance) =>
               Distance * nmTometer;
        public static double NmToKmeter(double Distance) =>
                Distance * nmToKmeter;
        public static double KmeterTometer(double Distance) =>
                  Distance * kmeterTometer;
        public static double KmeterToNM(double Distance) =>
                Distance * kmeterToNM;

        public static double MeterToKm(double Distance) =>
               Distance * meterToKm;
        public static double MeterToNm(double Distance) =>
                Distance * meterToKt;

        public static double MeterparstoKmh(double vitesse) =>
              vitesse * meterparstoKmh;
        public static double KmhtoMeterpars(double vitesse) =>
               vitesse * kmhtometerpars;

        public static double MeterparstoKt(double vitesse) =>
            vitesse * meterparstokt;
        public static double KttoMeterpars(double vitesse) =>
             vitesse * kttometerpars;
        public static double KmhtoKt(double vitesse) =>
              vitesse * kmhtoKt;
        public static double KttoKmh(double vitesse) =>
               vitesse * kttokmh;


        public static double MetersToFeet(double distance) =>
       distance * metersToFeet;
        public static double FeetToMeters(double distance) =>
       distance * feetToMeters;
        public static double KilometersToFeet(double distance) =>
       distance * kilometersToFeet;
        public static double FeetToKilometers(double distance) =>
       distance * feetToKilometers;



        public static double FahrenheitToCelsius(double fahrenheit) =>
            (fahrenheit - 32.0) / 1.8;

        public static double CelsiusToFahrenheit(double celsius) =>
            celsius * 1.8 + 32.0;

        public static double CelsiusToKelvin(double celsius) =>
           celsius + celsiusToKelvin;

        public static double KelvinToCelsius(double kelvin) =>
           kelvin - celsiusToKelvin;

        public static double MilesToMeters(double miles) =>
            miles * milesToMeters;

        public static double MilesToKilometers(double miles) =>
            miles * milesToKilometers;

        public static double KilometersToMiles(double kilometers) =>
            kilometers * kilometersToMiles;

        public static double DegreesToRadians(double degrees) =>
            degrees * degreesToRadians;

        public static double RadiansToDegrees(double radians) =>
            radians / degreesToRadians;

        public static double PoundsToKilograms(double pounds) =>
            pounds * poundsToKg;

        public static double PoundsToStones(double pounds) =>
            pounds * poundsToStones;

        public static double StonesToPounds(double stones) =>
           stones * stonesToPounds;

        public static double KilogramsToPounds(double kilograms) =>
            kilograms * kgToPounds;

        public static double DegreesPerSecondToRadiansPerSecond(double degrees) =>
            HertzToRadiansPerSecond(DegreesPerSecondToHertz(degrees));

        public static double RadiansPerSecondToDegreesPerSecond(double radians) =>
            HertzToDegreesPerSecond(RadiansPerSecondToHertz(radians));

        public static double DegreesPerSecondToHertz(double degrees) =>
            degrees / totalDegrees;

        public static double RadiansPerSecondToHertz(double radians) =>
            radians / twoPi;

        public static double HertzToDegreesPerSecond(double hertz) =>
            hertz * totalDegrees;

        public static double HertzToRadiansPerSecond(double hertz) =>
            hertz * twoPi;

        public static double KilopascalsToHectopascals(double kpa) =>
            kpa * 10.0;

        public static double HectopascalsToKilopascals(double hpa) =>
            hpa / 10.0;

        public static double KilopascalsToPascals(double kpa) =>
            kpa * 1000.0;

        public static double HectopascalsToPascals(double hpa) =>
            hpa * 100.0;

        public static double AtmospheresToPascals(double atm) =>
            atm * atmospherePascals;

        public static double PascalsToAtmospheres(double pascals) =>
            pascals / atmospherePascals;

        public static double CoordinatesToMiles(double lat1, double lon1, double lat2, double lon2) =>
            KilometersToMiles(CoordinatesToKilometers(lat1, lon1, lat2, lon2));

        public static double CoordinatesToKilometers(double lat1, double lon1, double lat2, double lon2)
        {
            if (lat1 == lat2 && lon1 == lon2)
                return 0;

            var dLat = DegreesToRadians(lat2 - lat1);
            var dLon = DegreesToRadians(lon2 - lon1);

            lat1 = DegreesToRadians(lat1);
            lat2 = DegreesToRadians(lat2);

            var dLat2 = Math.Sin(dLat / 2) * Math.Sin(dLat / 2);
            var dLon2 = Math.Sin(dLon / 2) * Math.Sin(dLon / 2);

            var a = dLat2 + dLon2 * Math.Cos(lat1) * Math.Cos(lat2);
            var c = 2 * Math.Asin(Math.Sqrt(a));

            return meanEarthRadiusInKilometers * c;
        }

        public static double CoordinatesDD_ToRadiansAzimut(double lat1, double lon1, double lat2, double lon2)
        {
            // lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180
            double azimut;

            // Résolution des cas simples : même coordonnées, même latitude, même longitude ou encore un point sur les pôles
            if (lat1 == lat2 && lon1 == lon2)
            {
                azimut = 0;
            }
            else if(lat1 == lat2) // soit on va vers l'est, soit vers l'ouest
            {
                if(Math.Abs(lon2 - lon1) <= 180) // si lon2 > lon1, alors on va vers l'est et on va vers l'ouest sinon
                {
                    if(lon2 > lon1)
                    {
                        azimut = 90; // est
                    }
                    else
                    {
                        azimut = 270; // ouest
                    }
                }
                else // lon2 > lon1, alors on va vers l'ouest et on va vers l'est sinon
                {
                    if (lon2 > lon1)
                    {
                        azimut = 270; // ouest
                    }
                    else
                    {
                        azimut = 90; // est
                    }
                }
            }
            else if(lon1 == lon2) // soit on va vers le nord, soit vers le sud
            {
                if(lat2 > lat1)
                {
                    azimut = 0; // nord
                }
                else
                {
                    azimut = 180; // sud
                }
            }
            else if(lat1 == -90 || lat2 == 90)
            {
                azimut = 0; // on va forcément vers le nord
            }
            else if(lat1 == 90 || lat2 == -90)
            {
                azimut = 180; // on va forcément vers le sud
            }
            else
            {
                // Voir formule donnée dans rapport de stage 2023 Anaël Courjaud OU
                // « Calcul de la direction sachant 2 points », Azimut, dCode.fr, [URL :] https://www.dcode.fr/azimut, consulté le 22/06/2023.

                double x = Math.Cos(lat1) * Math.Sin(lat2) - Math.Sin(lat1) * Math.Cos(lat2) * Math.Cos(lon2 - lon1);
                double y = Math.Sin(lon2 - lon1) * Math.Cos(lat2);

                double quotient = y / (Math.Sqrt(x * x + y * y) + x);

                azimut = 2 * Math.Atan(quotient);
            }


            return azimut;
        }



        public static string[] coordinatesDD_ToCoordinatesDDM(Location coordsDD)
        {
            double lat = coordsDD.Latitude;
            double lon = coordsDD.Longitude;

            string lettreLat = lat >= 0 ? "N" : "S";
            string lettreLon = lon >= 0 ? "E" : "W";

            lat = Math.Abs(lat);
            lon = Math.Abs(lon);

            int degLat = (int)Math.Floor(lat);
            int degLon = (int)Math.Floor(lon);

            lat = Math.Round((lat - degLat) * 60, 4); 
            lon = Math.Round((lon - degLon) * 60, 4);

            string[] tabCoordsDDM = new string[]
            {
                degLat.ToString() + "° " + lat.ToString() + "' " + lettreLat,
                degLon.ToString() + "° " + lon.ToString() + "' " + lettreLon
            };


            return tabCoordsDDM;
        }



        public static string[] coordinatesDD_ToCoordinatesDMS(Location coordsDD)
        {
            double lat = coordsDD.Latitude;
            double lon = coordsDD.Longitude;

            string lettreLat = lat >= 0 ? "N" : "S";
            string lettreLon = lon >= 0 ? "E" : "W";

            lat = Math.Abs(lat);
            lon = Math.Abs(lon);

            int degLat = (int)Math.Floor(lat);
            int degLon = (int)Math.Floor(lon);

            lat = (lat - degLat) * 60;
            lon = (lon - degLon) * 60;

            int minLat = (int)Math.Floor(lat);
            int minLon = (int)Math.Floor(lon);

            lat = Math.Round((lat - minLat) * 60, 4);
            lon = Math.Round((lon - minLon) * 60, 4);

            string[] tabCoordsDMS = new string[]
            {
                degLat.ToString() + "° " + minLat.ToString() + "' " + lat.ToString() + "'' " + lettreLat,
                degLon.ToString() + "° " + minLon.ToString() + "' " + lon.ToString() + "'' " + lettreLon
            };


            return tabCoordsDMS;
        }


        public static string intToHexadecimal(int intBetween0and255)
        {
            string valeurRetour = "";

            string[] chiffresHexa = new string[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F" };

            if(intBetween0and255 < 0 || intBetween0and255 > 255)
            {
                valeurRetour = "00";
            }
            else
            {
                int quotient16 = intBetween0and255 / 16;
                int reste = intBetween0and255 % 16;

                valeurRetour += chiffresHexa[quotient16];
                valeurRetour += chiffresHexa[reste];
            }

            return valeurRetour;
        }


        /// <summary>
        /// International survey foot defined as exactly 0.3048 meters by convention in 1959. This is the most common modern foot measure.
        /// </summary>
        public static double MetersToInternationalFeet(double meters) =>
            meters / internationalFootDefinition;

        /// <summary>
        /// International survey foot defined as exactly 0.3048 meters by convention in 1959. This is the most common modern foot measure.
        /// </summary>
        public static double InternationalFeetToMeters(double internationalFeet) =>
            internationalFeet * internationalFootDefinition;

        /// <summary>
        /// Exactly 1200/3937 meters by definition. In decimal terms approximately 0.304 800 609 601 219 meters. Variation from the common international foot of exactly 0.3048 meters may only be considerable over large survey distances.
        /// </summary>
        public static double MetersToUSSurveyFeet(double meters) =>
            meters / usSurveyFootDefinition;

        /// <summary>
        /// Exactly 1200/3937 meters by definition. In decimal terms approximately 0.304 800 609 601 219 meters. Variation from the common international foot of exactly 0.3048 meters may only be considerable over large survey distances.
        /// </summary>
        public static double USSurveyFeetToMeters(double usFeet) =>
            usFeet * usSurveyFootDefinition;



        public static float majDistanceUnit(float distanceInMeters)
        {
            if (ConfigData.paramDistanceUnit_0m_1ft_2km == 2)
            {
                distanceInMeters = (float)MeterToKm(distanceInMeters);
            }
            else if (ConfigData.paramDistanceUnit_0m_1ft_2km == 1)
            {
                distanceInMeters = (float)MetersToFeet(distanceInMeters);
            }
            else
            {
                // on considère qu'il faut mettre en metres or c'est déjà en metres, donc on ne fait rien.
            }

            return distanceInMeters;
        }
    }
}
